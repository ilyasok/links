Zoom is a script for Adobe After Effects that can smoothly change zoom in your Composition View.

---------------------------------

Run the script.
Open After Effects, go to "File -> Scripts -> Run Script File..." and open Zoom.jsx. A new Script UI window will pop up.

---------------------------------

It is recommended to install the script as a dockable panel to always have it accessible inside After Effects. 
There are two options:

Install via After Effects:
  Open After Effects, go to "File -> Scripts -> Install Script UI Panel..." and open Zoom.jsx.

Manual Installation:
  Copy Zoom.jsx to:
     Windows: C:\Program Files\Adobe\Adobe After Effects [version]\Support Files\Scripts\ScriptUI Panels\
     macOS: /Applications/Adobe After Effects [version]/Scripts/ScriptUI Panels/

Restart After Effects after installation and you should be able to find the script under the Window menu.

---------------------------------

Install Zoom plug-in.

Zoom plug-in extends the script functionality by providing:
  - Key Bindings: Allows users to interact with all Zoom features directly via keyboard and mouse (e.g. Ctrl + Scroll Up), eliminating the need to launch the script.
  - Experimental features: Offers an improved zooming experience that aims to replicate the feel of After Effects' native zoom functionality.

How to install the plug-in:
1. Find the plug-in file inside this archive. The location of the plug-in file depends on your operating system:
    Windows: "Plug-in/Windows/Zoom.aex"
    macOS: "Plug-in/macOS/Zoom.plugin"
2. Copy the plug-in file (Zoom.aex for Windows or Zoom.plugin for macOS) in one of the following directories:

  (Recommended) For all After Effects versions:
    Windows: C:\Program Files\Adobe\Common\Plug-ins\7.0\MediaCore\
    macOS: /Library/Application Support/Adobe/Common/Plug-ins/7.0/MediaCore/
  
  For a specific After Effects version:
    Windows: C:\Program Files\Adobe\Adobe After Effects [version]\Support Files\Plug-ins\
    macOS:/Applications/Adobe After Effects [version]/Plug-ins/

3. Restart After Effects.

The plug-in launches automatically alongside After Effects after installation.

---------------------------------

Github repo: https://github.com/QuisPic/ae-zoom
Author: https://twitter.com/quismotion
email: hello@motionprincess.com