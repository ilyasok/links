var __zoomThisObj = this;
(function () {
  'use strict';

  var VERSION = "0.3.0";
  var OS = { WIN: 0, MAC: 1 };
  var AE_OS = $.os.indexOf("Win") !== -1 ? OS.WIN : OS.MAC;
  var PLUGIN_FILE_NAME = AE_OS === OS.WIN ? "Zoom.aex" : "Zoom.plugin";
  var SETTINGS_SECTION_NAME = "Quis/Ae_Smooth_Zoom";
  var BLUE_COLOR = [0.06, 0.52, 0.94, 1];
  var ZOOM_STEP_ON_BTN_CLICK = 1;
  var STICK_TO = { LEFT: 0, RIGHT: 1 };

  var ZOOM_PLUGIN_STATUS = {
    INITIALIZATION_ERROR: 0,
    INITIALIZED: 1,
    FINISHED: 2,
    NOT_FOUND: 3,
    FOUND_NOT_INITIALIZED: 4,
    INITIALIZED_NOT_FOUND: 5,
  };

  var UI_STATUS = {
    ERROR: 0,
    OK: 1,
  };

  var KB_ACTION = {
    CHANGE: 0,
    DECREMENT: 1, // deprecated
    SET_TO: 2,
  };

  /** Change is written 2 times because old versions of this setting had 3 options
   * and first two were Increment/Decrement */
  var KB_ACTION_NAMES = {};
  KB_ACTION_NAMES[KB_ACTION.CHANGE] = "Change:";
  KB_ACTION_NAMES[KB_ACTION.DECREMENT] = "Change:";
  KB_ACTION_NAMES[KB_ACTION.SET_TO] = "Set to:";

  var DEFAULT_SETTINGS = {
    version: VERSION,
    keyBindings:
      AE_OS === OS.WIN
        ? [
            {
              enabled: true,
              keyCodes: { type: 11, mask: 34, keycode: 1 },
              action: KB_ACTION.CHANGE,
              amount: 1,
            },
            {
              enabled: true,
              keyCodes: { type: 11, mask: 34, keycode: 2 },
              action: KB_ACTION.CHANGE,
              amount: -1,
            },
            {
              enabled: false,
              keyCodes: { type: 4, mask: 34, keycode: 61 },
              action: KB_ACTION.CHANGE,
              amount: 1,
            },
            {
              enabled: false,
              keyCodes: { type: 4, mask: 34, keycode: 45 },
              action: KB_ACTION.CHANGE,
              amount: -1,
            },
          ]
        : [
            {
              enabled: true,
              keyCodes: { type: 11, mask: 68, keycode: 1 },
              action: KB_ACTION.CHANGE,
              amount: 1,
            },
            {
              enabled: true,
              keyCodes: { type: 11, mask: 68, keycode: 2 },
              action: KB_ACTION.CHANGE,
              amount: -1,
            },
            {
              enabled: false,
              keyCodes: { type: 4, mask: 68, keycode: 61 },
              action: KB_ACTION.CHANGE,
              amount: 1,
            },
            {
              enabled: false,
              keyCodes: { type: 4, mask: 68, keycode: 45 },
              action: KB_ACTION.CHANGE,
              amount: -1,
            },
          ],
    syncWithView: true,
    highDPI: {
      enabled: false,
      scale: 2,
    },
    showSlider: true,
    sliderMin: 1,
    sliderMax: 400,
    presetValues: [
      1.5, 3.1, 6.25, 12.5, 25, 33.3, 50, 100, 200, 400, 800, 1600, 3200, 6400,
    ],
    experimental: {
      detectCursorInsideView: false,
      fixViewportPosition: {
        enabled: false,
        zoomAround: 0,
      },
    },
  };

  /** Begin Mouse Buttons */
  var VC_LEFT_MOUSE_BUTTON = 1;
  var VC_RIGHT_MOUSE_BUTTON = 2;
  var VC_MIDDLE_MOUSE_BUTTON = 3;
  /** End Mouse Buttons */

  /** Begin Mouse Wheel */
  var SCROLL_DIRECTION_UP = 1;
  var SCROLL_DIRECTION_DOWN = 2;
  var SCROLL_DIRECTION_LEFT = 3;
  var SCROLL_DIRECTION_RIGHT = 4;
  /** End Mouse Wheel */

  /** Begin uiohook types */
  var MASK_SHIFT_L = 1 << 0;
  var MASK_CTRL_L = 1 << 1;
  var MASK_META_L = 1 << 2;
  var MASK_ALT_L = 1 << 3;

  var MASK_SHIFT_R = 1 << 4;
  var MASK_CTRL_R = 1 << 5;
  var MASK_META_R = 1 << 6;
  var MASK_ALT_R = 1 << 7;

  var MASK_SHIFT = MASK_SHIFT_L | MASK_SHIFT_R;
  var MASK_CTRL = MASK_CTRL_L | MASK_CTRL_R;
  var MASK_META = MASK_META_L | MASK_META_R;
  var MASK_ALT = MASK_ALT_L | MASK_ALT_R;
  var EVENT_KEY_PRESSED = 4;
  var EVENT_KEY_RELEASED = 5;
  var EVENT_MOUSE_PRESSED = 7;
  var EVENT_MOUSE_WHEEL = 11;

  /* Begin Virtual Key Codes */
  var VC_ESCAPE = 0x001b;

  // Begin Function Keys
  var VC_F1 = 0x0070;
  var VC_F2 = 0x0071;
  var VC_F3 = 0x0072;
  var VC_F4 = 0x0073;
  var VC_F5 = 0x0074;
  var VC_F6 = 0x0075;
  var VC_F7 = 0x0076;
  var VC_F8 = 0x0077;
  var VC_F9 = 0x0078;
  var VC_F10 = 0x0079;
  var VC_F11 = 0x007a;
  var VC_F12 = 0x007b;

  var VC_F13 = 0xf000;
  var VC_F14 = 0xf001;
  var VC_F15 = 0xf002;
  var VC_F16 = 0xf003;
  var VC_F17 = 0xf004;
  var VC_F18 = 0xf005;
  var VC_F19 = 0xf006;
  var VC_F20 = 0xf007;
  var VC_F21 = 0xf008;
  var VC_F22 = 0xf009;
  var VC_F23 = 0xf00a;
  var VC_F24 = 0xf00b;
  // End Function Keys

  // Begin Alphanumeric Zone
  var VC_BACK_QUOTE = 0x00c0; // GRAVE
  var VC_BACKQUOTE = VC_BACK_QUOTE; // Deprecated

  var VC_0 = 0x0030;
  var VC_1 = 0x0031;
  var VC_2 = 0x0032;
  var VC_3 = 0x0033;
  var VC_4 = 0x0034;
  var VC_5 = 0x0035;
  var VC_6 = 0x0036;
  var VC_7 = 0x0037;
  var VC_8 = 0x0038;
  var VC_9 = 0x0039;

  var VC_PLUS = 0x0209;
  var VC_MINUS = 0x002d;
  var VC_EQUALS = 0x003d;
  var VC_ASTERISK = 0x0097;

  var VC_AT = 0x0200;
  var VC_AMPERSAND = 0x0096;
  var VC_DOLLAR = 0x0203;
  var VC_EXCLAMATION_MARK = 0x0205;
  var VC_EXCLAMATION_DOWN = 0x0206; // Colombia & Mexico replaces '+/='

  var VC_BACKSPACE = 0x0008;

  var VC_TAB = 0x0009;
  var VC_CAPS_LOCK = 0x0014;

  var VC_A = 0x0041;
  var VC_B = 0x0042;
  var VC_C = 0x0043;
  var VC_D = 0x0044;
  var VC_E = 0x0045;
  var VC_F = 0x0046;
  var VC_G = 0x0047;
  var VC_H = 0x0048;
  var VC_I = 0x0049;
  var VC_J = 0x004a;
  var VC_K = 0x004b;
  var VC_L = 0x004c;
  var VC_M = 0x004d;
  var VC_N = 0x004e;
  var VC_O = 0x004f;
  var VC_P = 0x0050;
  var VC_Q = 0x0051;
  var VC_R = 0x0052;
  var VC_S = 0x0053;
  var VC_T = 0x0054;
  var VC_U = 0x0055;
  var VC_V = 0x0056;
  var VC_W = 0x0057;
  var VC_X = 0x0058;
  var VC_Y = 0x0059;
  var VC_Z = 0x005a;

  var VC_OPEN_BRACKET = 0x005b;
  var VC_CLOSE_BRACKET = 0x005c;
  var VC_BACK_SLASH = 0x005d;

  var VC_COLON = 0x0201;
  var VC_SEMICOLON = 0x003b;
  var VC_QUOTE = 0x00de;
  var VC_QUOTEDBL = 0x0098;
  var VC_ENTER = 0x000a;

  var VC_LESS = 0x0099;
  var VC_GREATER = 0x00a0;
  var VC_COMMA = 0x002c;
  var VC_PERIOD = 0x002e;
  var VC_SLASH = 0x002f;
  var VC_NUMBER_SIGN = 0x0208; // Used by Germany where the '/" key would be

  var VC_OPEN_BRACE = 0x00a1;
  var VC_CLOSE_BRACE = 0x00a2;

  var VC_OPEN_PARENTHESIS = 0x0207;
  var VC_CLOSE_PARENTHESIS = 0x020a;

  var VC_SPACE = 0x0020;
  // End Alphanumeric Zone

  // Begin Edit Key Zone
  var VC_PRINT_SCREEN = 0x009a; // SYSRQ
  var VC_SCROLL_LOCK = 0x0091;
  var VC_PAUSE = 0x0013;
  var VC_CANCEL = 0x00d3; // BREAK

  var VC_INSERT = 0x009b;
  var VC_DELETE = 0x007f;
  var VC_HOME = 0x0024;
  var VC_END = 0x0023;
  var VC_PAGE_UP = 0x0021;
  var VC_PAGE_DOWN = 0x0022;
  // End Edit Key Zone

  // Begin Cursor Key Zone
  var VC_UP = 0x0026;
  var VC_LEFT = 0x0025;
  var VC_BEGIN = 0xff58;
  var VC_RIGHT = 0x0027;
  var VC_DOWN = 0x0028;
  // End Cursor Key Zone

  // Begin Numeric Zone
  var VC_NUM_LOCK = 0x0090;
  var VC_KP_CLEAR = 0x000c;

  var VC_KP_DIVIDE = 0x006f;
  var VC_KP_MULTIPLY = 0x006a;
  var VC_KP_SUBTRACT = 0x006d;
  var VC_KP_EQUALS = 0x007c;
  var VC_KP_ADD = 0x006b;
  var VC_KP_ENTER = 0x007d;
  var VC_KP_DECIMAL = 0x006e;
  var VC_KP_SEPARATOR = 0x006c;
  var VC_KP_COMMA = 0x007e; // This may only be available on OS X?

  var VC_KP_0 = 0x0060;
  var VC_KP_1 = 0x0061;
  var VC_KP_2 = 0x0062;
  var VC_KP_3 = 0x0063;
  var VC_KP_4 = 0x0064;
  var VC_KP_5 = 0x0065;
  var VC_KP_6 = 0x0066;
  var VC_KP_7 = 0x0067;
  var VC_KP_8 = 0x0068;
  var VC_KP_9 = 0x0069;

  var VC_KP_END = 0xee00 | VC_KP_1;
  var VC_KP_DOWN = 0xee00 | VC_KP_2;
  var VC_KP_PAGE_DOWN = 0xee00 | VC_KP_3;
  var VC_KP_LEFT = 0xee00 | VC_KP_4;
  var VC_KP_BEGIN = 0xee00 | VC_KP_5;
  var VC_KP_RIGHT = 0xee00 | VC_KP_6;
  var VC_KP_HOME = 0xee00 | VC_KP_7;
  var VC_KP_UP = 0xee00 | VC_KP_8;
  var VC_KP_PAGE_UP = 0xee00 | VC_KP_9;
  var VC_KP_INSERT = 0xee00 | VC_KP_0;
  var VC_KP_DELETE = 0xee00 | VC_KP_SEPARATOR;
  // End Numeric Zone

  var VC_EX_PAGE_UP = 0xee00 | VC_PAGE_UP;
  var VC_EX_PAGE_DOWN = 0xee00 | VC_PAGE_DOWN;
  var VC_EX_END = 0xee00 | VC_END;
  var VC_EX_HOME = 0xee00 | VC_HOME;
  var VC_EX_LEFT = 0xee00 | VC_LEFT;
  var VC_EX_UP = 0xee00 | VC_UP;
  var VC_EX_RIGHT = 0xee00 | VC_RIGHT;
  var VC_EX_DOWN = 0xee00 | VC_DOWN;
  var VC_EX_INSERT = 0xee00 | VC_INSERT;
  var VC_EX_DELETE = 0xee00 | VC_DELETE;
  var VC_EX_ENTER = 0x0e00 | VC_ENTER;

  // Begin Modifier and Control Keys
  var VC_SHIFT_L = 0xa010;
  var VC_SHIFT_R = 0xb010;
  var VC_CONTROL_L = 0xa011;
  var VC_CONTROL_R = 0xb011;
  var VC_ALT_L = 0xa012; // Option or Alt Key
  var VC_ALT_R = 0xb012; // Option or Alt Key
  var VC_ALT_GRAPH = 0xff7e; // Replaces Right Alt Key
  var VC_META_L = 0xa09d; // Windows or Command Key
  var VC_META_R = 0xb09d; // Windows or Command Key
  var VC_CONTEXT_MENU = 0x020d;
  // End Modifier and Control Keys

  // Begin European Language Keys
  var VC_CIRCUMFLEX = 0x0202;
  var VC_DEAD_GRAVE = 0x0080;
  var VC_DEAD_ACUTE = 0x0081;
  var VC_DEAD_CIRCUMFLEX = 0x0082;
  var VC_DEAD_TILDE = 0x0083;
  var VC_DEAD_MACRON = 0x0084;
  var VC_DEAD_BREVE = 0x0085;
  var VC_DEAD_ABOVEDOT = 0x0086;
  var VC_DEAD_DIAERESIS = 0x0087;
  var VC_DEAD_ABOVERING = 0x0088;
  var VC_DEAD_DOUBLEACUTE = 0x0089;
  var VC_DEAD_CARON = 0x008a;
  var VC_DEAD_CEDILLA = 0x008b;
  var VC_DEAD_OGONEK = 0x008c;
  var VC_DEAD_IOTA = 0x008d;
  var VC_DEAD_VOICED_SOUND = 0x008e;
  var VC_DEAD_SEMIVOICED_SOUND = 0x008f;
  // End European Language Keys

  // Begin Asian Language Keys
  var VC_KATAKANA = 0x00f1;
  var VC_KANA = 0x0015;
  var VC_KANA_LOCK = 0x0106;

  var VC_KANJI = 0x0019;
  var VC_HIRAGANA = 0x00f2;

  var VC_ACCEPT = 0x001e;
  var VC_CONVERT = 0x001c;
  var VC_COMPOSE = 0xff20;
  var VC_INPUT_METHOD_ON_OFF = 0x0107;

  var VC_ALL_CANDIDATES = 0x0100;
  var VC_ALPHANUMERIC = 0x00f0;
  var VC_CODE_INPUT = 0x0102;
  var VC_FULL_WIDTH = 0x00f3;
  var VC_HALF_WIDTH = 0x00f4;
  var VC_NONCONVERT = 0x001d;
  var VC_PREVIOUS_CANDIDATE = 0x0101;
  var VC_ROMAN_CHARACTERS = 0x00f5;

  var VC_UNDERSCORE = 0x020b;
  // End Asian Language Keys

  // Begin Sun Keys
  var VC_SUN_HELP = 0xff75;

  var VC_SUN_STOP = 0xff78;
  var VC_SUN_PROPS = 0xff76;
  var VC_SUN_FRONT = 0xff77;
  var VC_SUN_OPEN = 0xff74;
  var VC_SUN_FIND = 0xff7e;
  var VC_SUN_AGAIN = 0xff79;
  var VC_SUN_UNDO = 0xff7a;
  var VC_SUN_COPY = 0xff7c;
  var VC_SUN_PASTE = 0xff7d;
  var VC_SUN_INSERT = VC_SUN_PASTE; // Deprecated
  var VC_SUN_CUT = 0xff7b;
  // End Sun Keys

  var VC_UNDEFINED = 0x0000; // KeyCode Unknown
  /* End Virtual Key Codes */

  /** Begin VC Map */
  var VC_MAP = {};
  VC_MAP[VC_ESCAPE] = "Escape";

  VC_MAP[VC_F1] = "F1";
  VC_MAP[VC_F2] = "F2";
  VC_MAP[VC_F3] = "F3";
  VC_MAP[VC_F4] = "F4";
  VC_MAP[VC_F5] = "F5";
  VC_MAP[VC_F6] = "F6";
  VC_MAP[VC_F7] = "F7";
  VC_MAP[VC_F8] = "F8";
  VC_MAP[VC_F9] = "F9";
  VC_MAP[VC_F10] = "F10";
  VC_MAP[VC_F11] = "F11";
  VC_MAP[VC_F12] = "F12";

  VC_MAP[VC_F13] = "F13";
  VC_MAP[VC_F14] = "F14";
  VC_MAP[VC_F15] = "F15";
  VC_MAP[VC_F16] = "F16";
  VC_MAP[VC_F17] = "F17";
  VC_MAP[VC_F18] = "F18";
  VC_MAP[VC_F19] = "F19";
  VC_MAP[VC_F20] = "F20";
  VC_MAP[VC_F21] = "F21";
  VC_MAP[VC_F22] = "F22";
  VC_MAP[VC_F23] = "F23";
  VC_MAP[VC_F24] = "F24";

  VC_MAP[VC_BACKQUOTE] = "`";

  VC_MAP[VC_0] = "0";
  VC_MAP[VC_1] = "1";
  VC_MAP[VC_2] = "2";
  VC_MAP[VC_3] = "3";
  VC_MAP[VC_4] = "4";
  VC_MAP[VC_5] = "5";
  VC_MAP[VC_6] = "6";
  VC_MAP[VC_7] = "7";
  VC_MAP[VC_8] = "8";
  VC_MAP[VC_9] = "9";

  VC_MAP[VC_PLUS] = "+";
  VC_MAP[VC_MINUS] = "-";
  VC_MAP[VC_EQUALS] = "=";
  VC_MAP[VC_ASTERISK] = "*";

  VC_MAP[VC_AT] = "@";
  VC_MAP[VC_AMPERSAND] = "&";
  VC_MAP[VC_DOLLAR] = "$";
  VC_MAP[VC_EXCLAMATION_MARK] = "!";
  VC_MAP[VC_EXCLAMATION_DOWN] = "¡";

  VC_MAP[VC_BACKSPACE] = "Backspace";

  VC_MAP[VC_TAB] = "Tab";
  VC_MAP[VC_CAPS_LOCK] = "Caps Lock";

  VC_MAP[VC_A] = "A";
  VC_MAP[VC_B] = "B";
  VC_MAP[VC_C] = "C";
  VC_MAP[VC_D] = "D";
  VC_MAP[VC_E] = "E";
  VC_MAP[VC_F] = "F";
  VC_MAP[VC_G] = "G";
  VC_MAP[VC_H] = "H";
  VC_MAP[VC_I] = "I";
  VC_MAP[VC_J] = "J";
  VC_MAP[VC_K] = "K";
  VC_MAP[VC_L] = "L";
  VC_MAP[VC_M] = "M";
  VC_MAP[VC_N] = "N";
  VC_MAP[VC_O] = "O";
  VC_MAP[VC_P] = "P";
  VC_MAP[VC_Q] = "Q";
  VC_MAP[VC_R] = "R";
  VC_MAP[VC_S] = "S";
  VC_MAP[VC_T] = "T";
  VC_MAP[VC_U] = "U";
  VC_MAP[VC_V] = "V";
  VC_MAP[VC_W] = "W";
  VC_MAP[VC_X] = "X";
  VC_MAP[VC_Y] = "Y";
  VC_MAP[VC_Z] = "Z";

  VC_MAP[VC_OPEN_BRACKET] = "[";
  VC_MAP[VC_CLOSE_BRACKET] = "]";
  VC_MAP[VC_BACK_SLASH] = "\\";

  VC_MAP[VC_COLON] = ":";
  VC_MAP[VC_SEMICOLON] = ";";
  VC_MAP[VC_QUOTE] = "'";
  VC_MAP[VC_QUOTEDBL] = '"';
  VC_MAP[VC_ENTER] = "Enter";

  VC_MAP[VC_LESS] = "<";
  VC_MAP[VC_GREATER] = ">";
  VC_MAP[VC_COMMA] = ",";
  VC_MAP[VC_PERIOD] = ".";
  VC_MAP[VC_SLASH] = "/";
  VC_MAP[VC_NUMBER_SIGN] = "#";

  VC_MAP[VC_OPEN_BRACE] = "{";
  VC_MAP[VC_CLOSE_BRACE] = "}";

  VC_MAP[VC_OPEN_PARENTHESIS] = "(";
  VC_MAP[VC_CLOSE_PARENTHESIS] = ")";

  VC_MAP[VC_SPACE] = "Space";

  VC_MAP[VC_PRINT_SCREEN] = "Print Screen";
  VC_MAP[VC_SCROLL_LOCK] = "Scroll Lock";
  VC_MAP[VC_PAUSE] = "Pause";
  VC_MAP[VC_CANCEL] = "Cancel";

  VC_MAP[VC_INSERT] = "Insert";
  VC_MAP[VC_DELETE] = "Delete";
  VC_MAP[VC_HOME] = "Home";
  VC_MAP[VC_END] = "End";
  VC_MAP[VC_PAGE_UP] = "Page Up";
  VC_MAP[VC_PAGE_DOWN] = "Page Down";

  VC_MAP[VC_UP] = "Up";
  VC_MAP[VC_LEFT] = "Left";
  VC_MAP[VC_BEGIN] = "Begin";
  VC_MAP[VC_RIGHT] = "Right";
  VC_MAP[VC_DOWN] = "Down";

  VC_MAP[VC_NUM_LOCK] = "Num Lock";
  VC_MAP[VC_KP_CLEAR] = "KP Clear";
  VC_MAP[VC_KP_DIVIDE] = "KP /";
  VC_MAP[VC_KP_MULTIPLY] = "KP *";
  VC_MAP[VC_KP_SUBTRACT] = "KP -";
  VC_MAP[VC_KP_EQUALS] = "KP =";
  VC_MAP[VC_KP_ADD] = "KP +";
  VC_MAP[VC_KP_ENTER] = "KP Enter";
  VC_MAP[VC_KP_DECIMAL] = "KP .";
  VC_MAP[VC_KP_SEPARATOR] = "KP Separator";
  VC_MAP[VC_KP_COMMA] = "KP ,";

  VC_MAP[VC_KP_0] = "0";
  VC_MAP[VC_KP_1] = "1";
  VC_MAP[VC_KP_2] = "2";
  VC_MAP[VC_KP_3] = "3";
  VC_MAP[VC_KP_4] = "4";
  VC_MAP[VC_KP_5] = "5";
  VC_MAP[VC_KP_6] = "6";
  VC_MAP[VC_KP_7] = "7";
  VC_MAP[VC_KP_8] = "8";
  VC_MAP[VC_KP_9] = "9";

  VC_MAP[VC_KP_END] = "KP End";
  VC_MAP[VC_KP_DOWN] = "KP Down";
  VC_MAP[VC_KP_PAGE_DOWN] = "KP Page Down";
  VC_MAP[VC_KP_LEFT] = "KP Left";
  VC_MAP[VC_KP_BEGIN] = "KP Begin";
  VC_MAP[VC_KP_RIGHT] = "KP Right";
  VC_MAP[VC_KP_HOME] = "KP Home";
  VC_MAP[VC_KP_UP] = "KP Up";
  VC_MAP[VC_KP_PAGE_UP] = "KP Page Up";
  VC_MAP[VC_KP_INSERT] = "KP Insert";
  VC_MAP[VC_KP_DELETE] = "KP Delete";

  VC_MAP[VC_EX_END] = "End";
  VC_MAP[VC_EX_DOWN] = "Down";
  VC_MAP[VC_EX_PAGE_DOWN] = "Page Down";
  VC_MAP[VC_EX_LEFT] = "Left";
  VC_MAP[VC_EX_RIGHT] = "Right";
  VC_MAP[VC_EX_HOME] = "Home";
  VC_MAP[VC_EX_UP] = "Up";
  VC_MAP[VC_EX_PAGE_UP] = "Page Up";
  VC_MAP[VC_EX_INSERT] = "Insert";
  VC_MAP[VC_EX_DELETE] = "Delete";
  VC_MAP[VC_EX_ENTER] = "Begin";

  VC_MAP[VC_SHIFT_L] = "Shift";
  VC_MAP[VC_SHIFT_R] = "Shift";
  VC_MAP[VC_CONTROL_L] = "Control";
  VC_MAP[VC_CONTROL_R] = "Control";
  VC_MAP[VC_ALT_L] = "Alt";
  VC_MAP[VC_ALT_R] = "Alt";
  VC_MAP[VC_ALT_GRAPH] = "Alt";
  VC_MAP[VC_META_L] = "Command";
  VC_MAP[VC_META_R] = "Command";
  VC_MAP[VC_CONTEXT_MENU] = "Menu";

  VC_MAP[VC_CIRCUMFLEX] = "^";
  VC_MAP[VC_DEAD_GRAVE] = "Grave";
  VC_MAP[VC_DEAD_ACUTE] = "Acute";
  VC_MAP[VC_DEAD_CIRCUMFLEX] = "Circumflex";
  VC_MAP[VC_DEAD_TILDE] = "Tilde";
  VC_MAP[VC_DEAD_MACRON] = "Macron";
  VC_MAP[VC_DEAD_BREVE] = "Breve";
  VC_MAP[VC_DEAD_ABOVEDOT] = "Above Dot";
  VC_MAP[VC_DEAD_DIAERESIS] = "Diaeresis";
  VC_MAP[VC_DEAD_ABOVERING] = "Above Ring";
  VC_MAP[VC_DEAD_DOUBLEACUTE] = "Double Acute";
  VC_MAP[VC_DEAD_CARON] = "Caron";
  VC_MAP[VC_DEAD_CEDILLA] = "Cedilla";
  VC_MAP[VC_DEAD_OGONEK] = "Ogonek";
  VC_MAP[VC_DEAD_IOTA] = "Iota";
  VC_MAP[VC_DEAD_VOICED_SOUND] = "Voiced Sound";
  VC_MAP[VC_DEAD_SEMIVOICED_SOUND] = "Semivoiced Sound";

  VC_MAP[VC_KATAKANA] = "Katakana";
  VC_MAP[VC_KANA] = "Kana";
  VC_MAP[VC_KANA_LOCK] = "Kana Lock";

  VC_MAP[VC_KANJI] = "Kanji";
  VC_MAP[VC_HIRAGANA] = "Hiragana";

  VC_MAP[VC_ACCEPT] = "Accept";
  VC_MAP[VC_CONVERT] = "Convert";
  VC_MAP[VC_COMPOSE] = "Compose";
  VC_MAP[VC_INPUT_METHOD_ON_OFF] = "Input Method ON/OFF";

  VC_MAP[VC_ALL_CANDIDATES] = "All Candidates";
  VC_MAP[VC_ALPHANUMERIC] = "Alphanumeric";
  VC_MAP[VC_CODE_INPUT] = "Code Input";
  VC_MAP[VC_FULL_WIDTH] = "Full Width";
  VC_MAP[VC_HALF_WIDTH] = "Half Width";
  VC_MAP[VC_NONCONVERT] = "Nonconvert";
  VC_MAP[VC_PREVIOUS_CANDIDATE] = "Previous Candidate";
  VC_MAP[VC_ROMAN_CHARACTERS] = "Roman Characters";
  VC_MAP[VC_UNDERSCORE] = "Underscore";

  VC_MAP[VC_SUN_HELP] = "Help";
  VC_MAP[VC_SUN_STOP] = "Stop";
  VC_MAP[VC_SUN_PROPS] = "Props";
  VC_MAP[VC_SUN_FRONT] = "Front";
  VC_MAP[VC_SUN_OPEN] = "Open";
  VC_MAP[VC_SUN_FIND] = "Find";
  VC_MAP[VC_SUN_AGAIN] = "Again";
  VC_MAP[VC_SUN_UNDO] = "Undo";
  VC_MAP[VC_SUN_COPY] = "Copy";
  VC_MAP[VC_SUN_PASTE] = "Paste";
  VC_MAP[VC_SUN_INSERT] = "Insert";
  VC_MAP[VC_SUN_CUT] = "Cut";

  VC_MAP[VC_UNDEFINED] = "Undefined";
  /** End VC Map */

  function getPrimaryScreen() {
    for (var i = 0; i < $.screens.length; i++) {
      if ($.screens[i].primary) {
        return $.screens[i];
      }
    }

    return $.screens[0];
  }

  function checkOs() {
    return $.os.indexOf("Win") !== -1 ? OS.WIN : OS.MAC;
  }

  function makeDivisibleBy(val, divisor, goUp) {
    if (val % divisor) {
      var result;
      divisor = divisor < 0 ? Math.abs(divisor) : divisor;

      if (divisor < 1) {
        var epsilon = 0.00000000000001; // float-point math...

        divisor = 1 / divisor;

        result = goUp
          ? Math.ceil((val - epsilon) * divisor) / divisor
          : Math.floor((val + epsilon) * divisor) / divisor;
      } else {
        result = goUp
          ? Math.ceil(val / divisor) * divisor
          : Math.floor(val / divisor) * divisor;
      }

      return result;
    }

    return val;
  }

  function getElementLocationInWindow(element) {
    var location = [element.bounds.left, element.bounds.top];
    var parent = element.parent;

    while (parent) {
      location[0] += parent.bounds.left;
      location[1] += parent.bounds.top;

      parent = parent.parent;
    }

    return location;
  }

  function getPluginsFoldersPaths() {
    /** Default values */
    var result =
      AE_OS === OS.WIN
        ? {
            common:
              "C:\\Program Files\\Adobe\\Common\\Plug-ins\\7.0\\MediaCore\\",
            individual:
              "C:\\Program Files\\Adobe\\Adobe After Effects [version]\\Support Files\\Plug-ins\\",
          }
        : {
            common:
              "/Library/Application Support/Adobe/Common/Plug-ins/7.0/MediaCore/",
            individual: "/Applications/Adobe After Effects [version]/Plug-ins/",
          };

    /** Find windows common plug-ins folder */
    if (AE_OS === OS.WIN) {
      try {
        var ver = app.version;
        ver = ver.slice(0, ver.search(/\.|x/)) + ".0";

        /** query windows registry */
        var cmdStr =
          'reg query "HKLM\\SOFTWARE\\Adobe\\After Effects\\' +
          ver +
          '" /v CommonPluginInstallPath';
        var regValue = system.callSystem(cmdStr);

        /** split reg query output string to get the path to the plugins folder */
        regValue = regValue.split(/\r?\n/)[2];
        for (var i = 0; i < 3; i++) {
          regValue = regValue.slice(regValue.search(/(\s\S)/) + 1);
        }

        result.common = regValue;
      } catch (error) {
        /**/
      }
    }

    /** Find individual plug-ins folder */
    var packageFolder = Folder.appPackage;

    if (AE_OS === OS.MAC) {
      packageFolder.changePath("..");
    }

    if (packageFolder.exists) {
      var pluginsFolderArr = packageFolder.getFiles("Plug-ins");

      if (
        pluginsFolderArr &&
        pluginsFolderArr.length &&
        pluginsFolderArr[0] instanceof Folder
      ) {
        result.individual =
          pluginsFolderArr[0].fsName + (AE_OS === OS.WIN ? "\\" : "/");
      }
    }

    return result;
  }

  function openURL(url) {
    try {
      if (checkOs() === OS.WIN) {
        system.callSystem("explorer " + url);
      } else {
        system.callSystem("open '" + url + "'");
      }
    } catch (error) {
      if (
        error.message ===
        "Permission denied (is Preferences > Scripting & Expressions > Allow Scripts to Write Files and Access Network enabled?)"
      ) {
        alert(
          "Cannot open URL. Permission denied.\n" +
            'Enable "' +
            (AE_OS === OS.WIN
              ? "Edit > Preferences"
              : "After Effects > Settings") +
            ' > Scripting & Expressions > Allow Scripts to Write Files and Access Network."',
        );
      } else {
        alert("Error at line " + error.line + ":\n" + error.message);
      }
    }
  }

  function isModifierKey(keycode) {
    return (
      keycode === VC_SHIFT_L ||
      keycode === VC_SHIFT_R ||
      keycode === VC_CONTROL_L ||
      keycode === VC_CONTROL_R ||
      keycode === VC_ALT_L ||
      keycode === VC_ALT_R ||
      keycode === VC_ALT_GRAPH ||
      keycode === VC_META_L ||
      keycode === VC_META_R
    );
  }

  // get array of key names in readable format
  // from the info received from zoom plugin
  function keysFromKeyCodes(keyCodes) {
    var keys = [];
    var type = keyCodes.type;
    var mask = keyCodes.mask;
    var keycode = keyCodes.keycode;

    if (mask & MASK_CTRL) {
      keys.push("Control");
    }

    if (mask & MASK_META) {
      keys.push(AE_OS === OS.WIN ? "Win" : "Command");
    }

    if (mask & MASK_SHIFT) {
      keys.push("Shift");
    }

    if (mask & MASK_ALT) {
      keys.push(AE_OS === OS.WIN ? "Alt" : "Option");
    }

    if (type === EVENT_KEY_PRESSED) {
      if (!isModifierKey(keycode)) {
        var keyName = VC_MAP[keycode];

        if (keyName) {
          keys.push(keyName);
        } else {
          keys.push("[" + keycode + "]");
        }
      }
    } else if (type === EVENT_MOUSE_PRESSED) {
      switch (keycode) {
        case VC_LEFT_MOUSE_BUTTON:
          keys.push("Left Click");
          break;
        case VC_RIGHT_MOUSE_BUTTON:
          keys.push("Right Click");
          break;
        case VC_MIDDLE_MOUSE_BUTTON:
          keys.push("Middle Click");
          break;
        default:
          keys.push("Mouse Button " + keycode);
          break;
      }
    } else if (type === EVENT_MOUSE_WHEEL) {
      switch (keycode) {
        case SCROLL_DIRECTION_UP:
          keys.push("Scroll Up");
          break;
        case SCROLL_DIRECTION_DOWN:
          keys.push("Scroll Down");
          break;
        case SCROLL_DIRECTION_LEFT:
          keys.push("Scroll Left");
          break;
        case SCROLL_DIRECTION_RIGHT:
          keys.push("Scroll Right");
          break;
        default:
          keys.push("Scroll [" + keycode + "]");
          break;
      }
    }

    return keys;
  }

  /**
   * Return 0 <= i <= array.length such that !pred(array[i - 1]) && pred(array[i]).
   */
  function binarySearch(array, pred) {
    var lo = -1,
      hi = array.length;

    while (1 + lo < hi) {
      var mi = lo + ((hi - lo) >> 1);
      if (pred(array[mi])) {
        hi = mi;
      } else {
        lo = mi;
      }
    }

    return hi;
  }

  /** returns point relative to the parent supplied, parentEl must be a parent of childEl */
  function positionRelativeToParent(parentEl, childEl, position) {
    if (!position) {
      position = [0, 0];
    }

    var result = [
      position[0] + childEl.location[0],
      position[1] + childEl.location[1],
    ];
    var directParentEl = childEl.parent;

    while (directParentEl && parentEl !== directParentEl) {
      result[0] += directParentEl.location.x;
      result[1] += directParentEl.location.y;

      directParentEl = directParentEl.parent;
    }

    return result;
  }

  /** remove any non number charactes from a string, respects float point values */
  function strToNumStr(str) {
    var numStr = str.match(/^\d*\.?\d+/);

    if (numStr) {
      return numStr[0];
    }
  }

  function drawRoundRect(r, g, b, p, s) {
    var d = 2 * r; // round corner diameter

    var drawCircle = function (left, top) {
      g.ellipsePath(left, top, d, d);

      if (b) {
        g.fillPath(b);
      }
      if (p) {
        g.strokePath(p);
      }
    };

    if (d) {
      drawCircle(0, 0);
      drawCircle(s[0] - d, 0);
      drawCircle(s[0] - d, s[1] - d);
      drawCircle(0, s[1] - d);
    }

    g.newPath();
    g.moveTo(r, 0);
    g.lineTo(s[0] - r, 0);
    g.lineTo(s[0], r);
    g.lineTo(s[0], s[1] - r);
    g.lineTo(s[0] - r, s[1]);
    g.lineTo(r, s[1]);
    g.lineTo(0, s[1] - r);
    g.lineTo(0, r);

    if (b) {
      g.fillPath(b);
    }
    if (p) {
      g.strokePath(p);
    }
  }

  function MenuWindow() {
    this.element = new Window("palette", undefined, undefined, {
      // borderless doesn't work on MacOS so it's better to turn it off
      // to leave the "close" button visible
      borderless: AE_OS === OS.WIN ? true : false,
    });

    this.element.margins = 0;
    this.element.spacing = 0;
    this.element.alignChildren = ["fill", "top"];
    this.element.shouldCloseOnDeactivate = true;

    this.element.onDeactivate = function () {
      if (this.shouldCloseOnDeactivate) {
        this.close();
      }
    };

    this.element.pnl = this.element.add(
      "Panel { \
      spacing: 0, \
      margins: 0, \
      alignChildren: ['fill', 'top'], \
    }",
    );
  }

  // by default sticks this window to the clickEl, but if the targetEl is provided sticks to targetEl
  MenuWindow.prototype.stickTo = function (
    clickEl,
    stickTo,
    mouseEvent,
    targetEl,
  ) {
    targetEl = targetEl ? targetEl : clickEl;

    var location = [
      mouseEvent.screenX - mouseEvent.clientX,
      mouseEvent.screenY - mouseEvent.clientY + targetEl.size[1],
    ];

    if (targetEl !== clickEl) {
      location +=
        getElementLocationInWindow(targetEl) -
        getElementLocationInWindow(clickEl);
    }

    if (stickTo === STICK_TO.RIGHT) {
      location[0] += targetEl.size[0] - this.element.size[0];
    }

    // if the window is too long to fit in the screen height then make the list go up
    var primaryScreen = getPrimaryScreen();
    if (location[1] + this.element.size[1] > primaryScreen.bottom) {
      location[1] -= targetEl.size[1] + this.element.size[1];
    }

    this.element.frameLocation = location;
  };

  MenuWindow.prototype.addMenuItem = function (name, onClickFn) {
    var thisWindow = this;
    var valGroup = this.element.pnl.add(
      "Group { \
      margins: [7, 3, 15, 3], \
      preferredSize: [-1, 22], \
      alignChildren: ['left', 'center'], \
      txtValue: StaticText {}, \
    }",
    );

    var txtValue = valGroup.txtValue;
    txtValue.text = name;
    txtValue.graphics.foregroundColor = txtValue.graphics.newPen(
      txtValue.graphics.PenType.SOLID_COLOR,
      [0.75, 0.75, 0.75, 1],
      1,
    );

    var g = valGroup.graphics;
    g.backgroundColor = g.newBrush(
      g.BrushType.SOLID_COLOR,
      [0.12, 0.12, 0.12, 1],
    );

    valGroup.addEventListener("mouseover", function () {
      g.backgroundColor = g.newBrush(
        g.BrushType.SOLID_COLOR,
        [0.27, 0.27, 0.27, 1],
      );
    });

    valGroup.addEventListener("mouseout", function () {
      g.backgroundColor = g.newBrush(
        g.BrushType.SOLID_COLOR,
        [0.12, 0.12, 0.12, 1],
      );
    });

    if (typeof onClickFn === "function") {
      valGroup.addEventListener("click", function (event) {
        if (event.eventPhase === "target") {
          onClickFn();
          thisWindow.element.close();
        }
      });
    }

    return valGroup;
  };

  MenuWindow.prototype.addDivider = function () {
    this.element.pnl.add("panel");
  };

  function bind(fToBind, oThis) {
    if (fToBind.__class__ !== "Function") {
      throw new TypeError(
        "Function.prototype.bind - what is trying to be bound is not callable",
      );
    }

    var fNOP = function () {};
    var fBound = function () {
      return fToBind.apply(
        fToBind instanceof fNOP ? fToBind : oThis,
        Array.prototype.slice.call(arguments),
      );
    };

    if (this.prototype) {
      // Function.prototype doesn't have a prototype property
      fNOP.prototype = this.prototype;
    }

    fBound.prototype = new fNOP();

    return fBound;
  }

  function ZoomWindows() {
    this.windows = [];
  }

  ZoomWindows.prototype.close = function (uiObj) {
    if (typeof uiObj === "object" && uiObj.element && isValid(uiObj.element)) {
      uiObj.element.close();
    }
  };

  ZoomWindows.prototype.new = function (win) {
    var winObj;
    if (typeof win === "function") {
      winObj = new win();
    } else if (typeof win === "object") {
      winObj = win;
    } else {
      alert("Zoom error:\nCannot create new window of type " + typeof win);
      return;
    }

    /** close all windows of the same type */
    for (var i = 0; i < this.windows.length; i++) {
      if (this.windows[i].__proto__ === winObj.__proto__) {
        this.close(this.windows[i]);
      }
    }

    this.windows.push(winObj);

    return winObj;
  };

  var windows = new ZoomWindows();

  function ZoomPlugin() {
    this._status = undefined;
    this.foundEO = false;
    this.externalObject = undefined;
  }

  function isZoomPlugin(extObject) {
    return extObject && extObject.quis_zoom_plugin;
  }

  ZoomPlugin.prototype.loadPlugin = function (path) {
    try {
      var foundExtObject = ExternalObject.search("lib:" + path);
    } catch (error) {
      /**/
    }

    if (foundExtObject) {
      try {
        var extObject = new ExternalObject("lib:" + path);

        if (isZoomPlugin(extObject)) {
          this.foundEO = true;
          this.path = path;
          this.externalObject = extObject;
        }
      } catch (error) {
        /**/
      }
    }
  };

  ZoomPlugin.prototype.searchForPlugin = function (folder) {
    var files = folder.getFiles();

    for (var i = 0; i < files.length; i++) {
      this.loadPlugin(files[i].fsName);

      if (this.foundEO) {
        break;
      }
    }

    /** If plugin is not found is this folder search in sub-folders */
    if (!this.foundEO) {
      for (i = 0; i < files.length; i++) {
        if (files[i] instanceof Folder) {
          /** skip plug-ins on macos because they are treated as folders */
          if (AE_OS === OS.MAC && files[i].name.indexOf(".plugin") !== -1) {
            continue;
          }

          this.searchForPlugin(files[i]);

          if (this.foundEO) {
            break;
          }
        }
      }
    }
  };

  ZoomPlugin.prototype.findPlugin = function () {
    var pluginsFoldersPaths = getPluginsFoldersPaths();

    /** first check the default plug-in locations */
    this.loadPlugin(
      pluginsFoldersPaths.common.fsName +
        (AE_OS === OS.WIN ? "\\" : "/") +
        PLUGIN_FILE_NAME,
    );
    this.loadPlugin(
      pluginsFoldersPaths.common.fsName +
        (AE_OS === OS.WIN ? "\\" : "/") +
        PLUGIN_FILE_NAME,
    );

    /** if the plugin isn't found in the default folders
     * try to search explicitly in the plugins folders */
    if (!this.foundEO) {
      var pluginsFolders = [
        new Folder(pluginsFoldersPaths.common),
        new Folder(pluginsFoldersPaths.individual),
      ];

      for (var i = 0; i < pluginsFolders.length; i++) {
        if (!pluginsFolders[i].exists) {
          continue;
        }

        this.searchForPlugin(pluginsFolders[i]);

        if (this.foundEO) {
          break;
        }
      }
    }
  };

  ZoomPlugin.prototype.status = function () {
    if (this._status === undefined) {
      this._status = ZOOM_PLUGIN_STATUS.NOT_FOUND;

      if ($.global.__quis_zoom_plugin_is_loaded) {
        this._status = ZOOM_PLUGIN_STATUS.INITIALIZED_NOT_FOUND;

        if (!this.externalObject) {
          this.findPlugin();
        }

        if (this.externalObject) {
          try {
            if (this.externalObject.status) {
              this._status = ZOOM_PLUGIN_STATUS.FOUND_NOT_INITIALIZED;

              var pluginStatus = this.externalObject.status();

              if (pluginStatus !== undefined) {
                this._status = pluginStatus; // INITIALIZATION_ERROR or INITIALIZED
              }
            }
          } catch (error) {
            alert(
              "Error loading Zoom plug-in.\nError at line " +
                $.line +
                ":\n" +
                error.message,
            );
          }
        }
      }
    }

    return this._status;
  };

  ZoomPlugin.prototype.resetStatus = function () {
    this._status = undefined;
  };

  ZoomPlugin.prototype.isAvailable = function () {
    return this.status() === ZOOM_PLUGIN_STATUS.INITIALIZED;
  };

  ZoomPlugin.prototype.getError = function () {
    if (this.externalObject.getError) {
      return this.externalObject.getError();
    }
  };

  ZoomPlugin.prototype.reload = function () {
    if (this.externalObject.reload) {
      this._status = this.externalObject.reload();
    }
  };

  ZoomPlugin.prototype.updateKeyBindings = function () {
    if (this.externalObject.updateKeyBindings) {
      this.externalObject.updateKeyBindings();
    }
  };

  ZoomPlugin.prototype.updateExperimentalOptions = function () {
    if (this.externalObject.updateExperimentalOptions) {
      this.externalObject.updateExperimentalOptions();
    }
  };

  ZoomPlugin.prototype.updateHighDpiOptions = function () {
    if (this.externalObject.updateHighDpiOptions) {
      this.externalObject.updateHighDpiOptions();
    }
  };

  ZoomPlugin.prototype.startKeyCapture = function () {
    if (this.externalObject.startKeyCapture) {
      this.externalObject.startKeyCapture();
    }
  };

  ZoomPlugin.prototype.endKeyCapture = function () {
    if (this.externalObject.endKeyCapture) {
      this.externalObject.endKeyCapture();
    }
  };

  ZoomPlugin.prototype.postZoomAction = function (actionType, amount) {
    var isActionPosted = false;

    if (this.externalObject.postZoomAction) {
      isActionPosted = this.externalObject.postZoomAction(actionType, amount);
    }

    return isActionPosted;
  };

  ZoomPlugin.prototype.getVersion = function () {
    var result;

    if (this.externalObject.getVersion) {
      result = this.externalObject.getVersion();
    }

    return result;
  };

  var zoomPlugin = new ZoomPlugin();

  //  json2.js
  //  2017-06-12
  //  Public Domain.
  //  NO WARRANTY EXPRESSED OR IMPLIED. USE AT YOUR OWN RISK.

  //  USE YOUR OWN COPY. IT IS EXTREMELY UNWISE TO LOAD CODE FROM SERVERS YOU DO
  //  NOT CONTROL.

  //  This file creates a global JSON object containing two methods: stringify
  //  and parse. This file provides the ES5 JSON capability to ES3 systems.
  //  If a project might run on IE8 or earlier, then this file should be included.
  //  This file does nothing on ES5 systems.

  //      JSON.stringify(value, replacer, space)
  //          value       any JavaScript value, usually an object or array.
  //          replacer    an optional parameter that determines how object
  //                      values are stringified for objects. It can be a
  //                      function or an array of strings.
  //          space       an optional parameter that specifies the indentation
  //                      of nested structures. If it is omitted, the text will
  //                      be packed without extra whitespace. If it is a number,
  //                      it will specify the number of spaces to indent at each
  //                      level. If it is a string (such as "\t" or "&nbsp;"),
  //                      it contains the characters used to indent at each level.
  //          This method produces a JSON text from a JavaScript value.
  //          When an object value is found, if the object contains a toJSON
  //          method, its toJSON method will be called and the result will be
  //          stringified. A toJSON method does not serialize: it returns the
  //          value represented by the name/value pair that should be serialized,
  //          or undefined if nothing should be serialized. The toJSON method
  //          will be passed the key associated with the value, and this will be
  //          bound to the value.

  //          For example, this would serialize Dates as ISO strings.

  //              Date.prototype.toJSON = function (key) {
  //                  function f(n) {
  //                      // Format integers to have at least two digits.
  //                      return (n < 10)
  //                          ? "0" + n
  //                          : n;
  //                  }
  //                  return this.getUTCFullYear()   + "-" +
  //                       f(this.getUTCMonth() + 1) + "-" +
  //                       f(this.getUTCDate())      + "T" +
  //                       f(this.getUTCHours())     + ":" +
  //                       f(this.getUTCMinutes())   + ":" +
  //                       f(this.getUTCSeconds())   + "Z";
  //              };

  //          You can provide an optional replacer method. It will be passed the
  //          key and value of each member, with this bound to the containing
  //          object. The value that is returned from your method will be
  //          serialized. If your method returns undefined, then the member will
  //          be excluded from the serialization.

  //          If the replacer parameter is an array of strings, then it will be
  //          used to select the members to be serialized. It filters the results
  //          such that only members with keys listed in the replacer array are
  //          stringified.

  //          Values that do not have JSON representations, such as undefined or
  //          functions, will not be serialized. Such values in objects will be
  //          dropped; in arrays they will be replaced with null. You can use
  //          a replacer function to replace those with JSON values.

  //          JSON.stringify(undefined) returns undefined.

  //          The optional space parameter produces a stringification of the
  //          value that is filled with line breaks and indentation to make it
  //          easier to read.

  //          If the space parameter is a non-empty string, then that string will
  //          be used for indentation. If the space parameter is a number, then
  //          the indentation will be that many spaces.

  //          Example:

  //          text = JSON.stringify(["e", {pluribus: "unum"}]);
  //          // text is '["e",{"pluribus":"unum"}]'

  //          text = JSON.stringify(["e", {pluribus: "unum"}], null, "\t");
  //          // text is '[\n\t"e",\n\t{\n\t\t"pluribus": "unum"\n\t}\n]'

  //          text = JSON.stringify([new Date()], function (key, value) {
  //              return this[key] instanceof Date
  //                  ? "Date(" + this[key] + ")"
  //                  : value;
  //          });
  //          // text is '["Date(---current time---)"]'

  //      JSON.parse(text, reviver)
  //          This method parses a JSON text to produce an object or array.
  //          It can throw a SyntaxError exception.

  //          The optional reviver parameter is a function that can filter and
  //          transform the results. It receives each of the keys and values,
  //          and its return value is used instead of the original value.
  //          If it returns what it received, then the structure is not modified.
  //          If it returns undefined then the member is deleted.

  //          Example:

  //          // Parse the text. Values that look like ISO date strings will
  //          // be converted to Date objects.

  //          myData = JSON.parse(text, function (key, value) {
  //              var a;
  //              if (typeof value === "string") {
  //                  a =
  //   /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2}(?:\.\d*)?)Z$/.exec(value);
  //                  if (a) {
  //                      return new Date(Date.UTC(
  //                         +a[1], +a[2] - 1, +a[3], +a[4], +a[5], +a[6]
  //                      ));
  //                  }
  //                  return value;
  //              }
  //          });

  //          myData = JSON.parse(
  //              "[\"Date(09/09/2001)\"]",
  //              function (key, value) {
  //                  var d;
  //                  if (
  //                      typeof value === "string"
  //                      && value.slice(0, 5) === "Date("
  //                      && value.slice(-1) === ")"
  //                  ) {
  //                      d = new Date(value.slice(5, -1));
  //                      if (d) {
  //                          return d;
  //                      }
  //                  }
  //                  return value;
  //              }
  //          );

  //  This is a reference implementation. You are free to copy, modify, or
  //  redistribute.

  /*jslint
      eval, for, this
  */

  /*property
      JSON, apply, call, charCodeAt, getUTCDate, getUTCFullYear, getUTCHours,
      getUTCMinutes, getUTCMonth, getUTCSeconds, hasOwnProperty, join,
      lastIndex, length, parse, prototype, push, replace, slice, stringify,
      test, toJSON, toString, valueOf
  */


  // Create a JSON object only if one does not already exist. We create the
  // methods in a closure to avoid creating global variables.

  // if (typeof JSON !== "object") {
  var JSON = {};
  // }

  (function () {

      var rx_one = /^[\],:{}\s]*$/;
      var rx_two = /\\(?:["\\\/bfnrt]|u[0-9a-fA-F]{4})/g;
      var rx_three = /"[^"\\\n\r]*"|true|false|null|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?/g;
      var rx_four = /(?:^|:|,)(?:\s*\[)+/g;
      var rx_escapable = /[\\"\u0000-\u001f\u007f-\u009f\u00ad\u0600-\u0604\u070f\u17b4\u17b5\u200c-\u200f\u2028-\u202f\u2060-\u206f\ufeff\ufff0-\uffff]/g;
      var rx_dangerous = /[\u0000\u00ad\u0600-\u0604\u070f\u17b4\u17b5\u200c-\u200f\u2028-\u202f\u2060-\u206f\ufeff\ufff0-\uffff]/g;

      // function f(n) {
      //     // Format integers to have at least two digits.
      //     return (n < 10)
      //         ? "0" + n
      //         : n;
      // }

      // function this_value() {
      //     return this.valueOf();
      // }

      // if (typeof Date.prototype.toJSON !== "function") {

      //     Date.prototype.toJSON = function () {

      //         return isFinite(this.valueOf())
      //             ? (
      //                 this.getUTCFullYear()
      //                 + "-"
      //                 + f(this.getUTCMonth() + 1)
      //                 + "-"
      //                 + f(this.getUTCDate())
      //                 + "T"
      //                 + f(this.getUTCHours())
      //                 + ":"
      //                 + f(this.getUTCMinutes())
      //                 + ":"
      //                 + f(this.getUTCSeconds())
      //                 + "Z"
      //             )
      //             : null;
      //     };

      //     Boolean.prototype.toJSON = this_value;
      //     Number.prototype.toJSON = this_value;
      //     String.prototype.toJSON = this_value;
      // }

      var gap;
      var indent;
      var meta;
      var rep;


      function quote(string) {

  // If the string contains no control characters, no quote characters, and no
  // backslash characters, then we can safely slap some quotes around it.
  // Otherwise we must also replace the offending characters with safe escape
  // sequences.

          rx_escapable.lastIndex = 0;
          return rx_escapable.test(string)
              ? "\"" + string.replace(rx_escapable, function (a) {
                  var c = meta[a];
                  return typeof c === "string"
                      ? c
                      : "\\u" + ("0000" + a.charCodeAt(0).toString(16)).slice(-4);
              }) + "\""
              : "\"" + string + "\"";
      }


      function str(key, holder) {

  // Produce a string from holder[key].

          var i;          // The loop counter.
          var k;          // The member key.
          var v;          // The member value.
          var length;
          var mind = gap;
          var partial;
          var value = holder[key];

  // If the value has a toJSON method, call it to obtain a replacement value.

          if (
              value
              && typeof value === "object"
              && typeof value.toJSON === "function"
          ) {
              value = value.toJSON(key);
          }

  // If we were called with a replacer function, then call the replacer to
  // obtain a replacement value.

          if (typeof rep === "function") {
              value = rep.call(holder, key, value);
          }

  // What happens next depends on the value's type.

          switch (typeof value) {
          case "string":
              return quote(value);

          case "number":

  // JSON numbers must be finite. Encode non-finite numbers as null.

              return (isFinite(value))
                  ? String(value)
                  : "null";

          case "boolean":
          case "null":

  // If the value is a boolean or null, convert it to a string. Note:
  // typeof null does not produce "null". The case is included here in
  // the remote chance that this gets fixed someday.

              return String(value);

  // If the type is "object", we might be dealing with an object or an array or
  // null.

          case "object":

  // Due to a specification blunder in ECMAScript, typeof null is "object",
  // so watch out for that case.

              if (!value) {
                  return "null";
              }

  // Make an array to hold the partial results of stringifying this object value.

              gap += indent;
              partial = [];

  // Is the value an array?

              if (Object.prototype.toString.apply(value) === "[object Array]") {

  // The value is an array. Stringify every element. Use null as a placeholder
  // for non-JSON values.

                  length = value.length;
                  for (i = 0; i < length; i += 1) {
                      partial[i] = str(i, value) || "null";
                  }

  // Join all of the elements together, separated with commas, and wrap them in
  // brackets.

                  v = partial.length === 0
                      ? "[]"
                      : gap
                          ? (
                              "[\n"
                              + gap
                              + partial.join(",\n" + gap)
                              + "\n"
                              + mind
                              + "]"
                          )
                          : "[" + partial.join(",") + "]";
                  gap = mind;
                  return v;
              }

  // If the replacer is an array, use it to select the members to be stringified.

              if (rep && typeof rep === "object") {
                  length = rep.length;
                  for (i = 0; i < length; i += 1) {
                      if (typeof rep[i] === "string") {
                          k = rep[i];
                          v = str(k, value);
                          if (v) {
                              partial.push(quote(k) + (
                                  (gap)
                                      ? ": "
                                      : ":"
                              ) + v);
                          }
                      }
                  }
              } else {

  // Otherwise, iterate through all of the keys in the object.

                  for (k in value) {
                      if (Object.prototype.hasOwnProperty.call(value, k)) {
                          v = str(k, value);
                          if (v) {
                              partial.push(quote(k) + (
                                  (gap)
                                      ? ": "
                                      : ":"
                              ) + v);
                          }
                      }
                  }
              }

  // Join all of the member texts together, separated with commas,
  // and wrap them in braces.

              v = partial.length === 0
                  ? "{}"
                  : gap
                      ? "{\n" + gap + partial.join(",\n" + gap) + "\n" + mind + "}"
                      : "{" + partial.join(",") + "}";
              gap = mind;
              return v;
          }
      }

  // If the JSON object does not yet have a stringify method, give it one.

      if (typeof JSON.stringify !== "function") {
          meta = {    // table of character substitutions
              "\b": "\\b",
              "\t": "\\t",
              "\n": "\\n",
              "\f": "\\f",
              "\r": "\\r",
              "\"": "\\\"",
              "\\": "\\\\"
          };
          JSON.stringify = function (value, replacer, space) {

  // The stringify method takes a value and an optional replacer, and an optional
  // space parameter, and returns a JSON text. The replacer can be a function
  // that can replace values, or an array of strings that will select the keys.
  // A default replacer method can be provided. Use of the space parameter can
  // produce text that is more easily readable.

              var i;
              gap = "";
              indent = "";

  // If the space parameter is a number, make an indent string containing that
  // many spaces.

              if (typeof space === "number") {
                  for (i = 0; i < space; i += 1) {
                      indent += " ";
                  }

  // If the space parameter is a string, it will be used as the indent string.

              } else if (typeof space === "string") {
                  indent = space;
              }

  // If there is a replacer, it must be a function or an array.
  // Otherwise, throw an error.

              rep = replacer;
              if (replacer && typeof replacer !== "function" && (
                  typeof replacer !== "object"
                  || typeof replacer.length !== "number"
              )) {
                  throw new Error("JSON.stringify");
              }

  // Make a fake root object containing our value under the key of "".
  // Return the result of stringifying the value.

              return str("", {"": value});
          };
      }


  // If the JSON object does not yet have a parse method, give it one.

      if (typeof JSON.parse !== "function") {
          JSON.parse = function (text, reviver) {

  // The parse method takes a text and an optional reviver function, and returns
  // a JavaScript value if the text is a valid JSON text.

              var j;

              function walk(holder, key) {

  // The walk method is used to recursively walk the resulting structure so
  // that modifications can be made.

                  var k;
                  var v;
                  var value = holder[key];
                  if (value && typeof value === "object") {
                      for (k in value) {
                          if (Object.prototype.hasOwnProperty.call(value, k)) {
                              v = walk(value, k);
                              if (v !== undefined) {
                                  value[k] = v;
                              } else {
                                  delete value[k];
                              }
                          }
                      }
                  }
                  return reviver.call(holder, key, value);
              }


  // Parsing happens in four stages. In the first stage, we replace certain
  // Unicode characters with escape sequences. JavaScript handles many characters
  // incorrectly, either silently deleting them, or treating them as line endings.

              text = String(text);
              rx_dangerous.lastIndex = 0;
              if (rx_dangerous.test(text)) {
                  text = text.replace(rx_dangerous, function (a) {
                      return (
                          "\\u"
                          + ("0000" + a.charCodeAt(0).toString(16)).slice(-4)
                      );
                  });
              }

  // In the second stage, we run the text against regular expressions that look
  // for non-JSON patterns. We are especially concerned with "()" and "new"
  // because they can cause invocation, and "=" because it can cause mutation.
  // But just to be safe, we want to reject all unexpected forms.

  // We split the second stage into 4 regexp operations in order to work around
  // crippling inefficiencies in IE's and Safari's regexp engines. First we
  // replace the JSON backslash pairs with "@" (a non-JSON character). Second, we
  // replace all simple value tokens with "]" characters. Third, we delete all
  // open brackets that follow a colon or comma or that begin the text. Finally,
  // we look to see that the remaining characters are only whitespace or "]" or
  // "," or ":" or "{" or "}". If that is so, then the text is safe for eval.

              if (
                  rx_one.test(
                      text
                          .replace(rx_two, "@")
                          .replace(rx_three, "]")
                          .replace(rx_four, "")
                  )
              ) {

  // In the third stage we use the eval function to compile the text into a
  // JavaScript structure. The "{" operator is subject to a syntactic ambiguity
  // in JavaScript: it can begin a block or an object literal. We wrap the text
  // in parens to eliminate the ambiguity.

                  j = eval("(" + text + ")");

  // In the optional fourth stage, we recursively walk the new structure, passing
  // each name/value pair to a reviver function for possible transformation.

                  return (typeof reviver === "function")
                      ? walk({"": j}, "")
                      : j;
              }

  // If the text is not JSON parseable, then a SyntaxError is thrown.

              throw new SyntaxError("JSON.parse");
          };
      }
  }());

  function Preferences() {
    if (!app.preferences.havePref(SETTINGS_SECTION_NAME, "keyBindings")) {
      this.save("keyBindings", DEFAULT_SETTINGS.keyBindings);
    }
    if (!app.preferences.havePref(SETTINGS_SECTION_NAME, "syncWithView")) {
      this.save("syncWithView", DEFAULT_SETTINGS.syncWithView);
    }
    if (!app.preferences.havePref(SETTINGS_SECTION_NAME, "highDPI")) {
      this.save("highDPI", DEFAULT_SETTINGS.highDPI);
    }
    if (!app.preferences.havePref(SETTINGS_SECTION_NAME, "showSlider")) {
      this.save("showSlider", DEFAULT_SETTINGS.showSlider);
    }
    if (!app.preferences.havePref(SETTINGS_SECTION_NAME, "sliderMin")) {
      this.save("sliderMin", DEFAULT_SETTINGS.sliderMin);
    }
    if (!app.preferences.havePref(SETTINGS_SECTION_NAME, "sliderMax")) {
      this.save("sliderMax", DEFAULT_SETTINGS.sliderMax);
    }
    if (!app.preferences.havePref(SETTINGS_SECTION_NAME, "presetValues")) {
      this.save("presetValues", DEFAULT_SETTINGS.presetValues);
    }
    if (!app.preferences.havePref(SETTINGS_SECTION_NAME, "experimental")) {
      this.save("experimental", DEFAULT_SETTINGS.experimental);
    }

    this.keyBindings = app.preferences.getPrefAsString(
      SETTINGS_SECTION_NAME,
      "keyBindings",
    );

    this.syncWithView = app.preferences.getPrefAsBool(
      SETTINGS_SECTION_NAME,
      "syncWithView",
    );

    this.highDPI = JSON.parse(
      app.preferences.getPrefAsString(SETTINGS_SECTION_NAME, "highDPI"),
    );

    this.showSlider = app.preferences.getPrefAsBool(
      SETTINGS_SECTION_NAME,
      "showSlider",
    );

    this.sliderMin = app.preferences.getPrefAsFloat(
      SETTINGS_SECTION_NAME,
      "sliderMin",
    );

    this.sliderMax = app.preferences.getPrefAsFloat(
      SETTINGS_SECTION_NAME,
      "sliderMax",
    );

    this.presetValues = app.preferences.getPrefAsString(
      SETTINGS_SECTION_NAME,
      "presetValues",
    );

    this.experimental = JSON.parse(
      app.preferences.getPrefAsString(SETTINGS_SECTION_NAME, "experimental"),
    );
  }

  Preferences.prototype.save = function (key, value) {
    if (typeof value === "boolean") {
      app.preferences.savePrefAsBool(SETTINGS_SECTION_NAME, key, value);
    } else if (typeof value === "number") {
      app.preferences.savePrefAsFloat(SETTINGS_SECTION_NAME, key, value);
    } else if (typeof value === "string") {
      app.preferences.savePrefAsString(SETTINGS_SECTION_NAME, key, value);
    } else if (typeof value === "object") {
      app.preferences.savePrefAsString(
        SETTINGS_SECTION_NAME,
        key,
        JSON.stringify(value),
      );
    }

    /** If the plugin is available and the preference that was saved is related to the plugin
     * then tell the plugin to read the updated option.
     */
    if (zoomPlugin.isAvailable()) {
      switch (key) {
        case "keyBindings":
          zoomPlugin.updateKeyBindings();
          break;
        case "experimental":
          zoomPlugin.updateExperimentalOptions();
          break;
        case "highDPI":
          zoomPlugin.updateHighDpiOptions();
          break;
      }
    }

    this[key] = value;
  };

  var preferences = new Preferences();

  var create = (function () {
    // To save on memory, use a shared constructor
    function Temp() {}

    // make a safe reference to Object.prototype.hasOwnProperty
    var hasOwn = Object.prototype.hasOwnProperty;

    return function (O) {
      // 1. If Type(O) is not Object or Null throw a TypeError exception.
      if (Object(O) !== O && O !== null) {
        throw TypeError("Object prototype may only be an Object or null");
      }

      // 2. Let obj be the result of creating a new object as if by the
      //    expression new Object() where Object is the standard built-in
      //    constructor with that name
      // 3. Set the [[Prototype]] internal property of obj to O.
      Temp.prototype = O;
      var obj = new Temp();
      Temp.prototype = null; // Let's not keep a stray reference to O...

      // 4. If the argument Properties is present and not undefined, add
      //    own properties to obj as if by calling the standard built-in
      //    function Object.defineProperties with arguments obj and
      //    Properties.
      if (arguments.length > 1) {
        // Object.defineProperties does ToObject on its first argument.
        var Properties = Object(arguments[1]);
        for (var prop in Properties) {
          if (hasOwn.call(Properties, prop)) {
            var descriptor = Properties[prop];
            if (Object(descriptor) !== descriptor) {
              throw TypeError(prop + "must be an object");
            }
            if ("get" in descriptor || "set" in descriptor) {
              throw new TypeError(
                "getters & setters can not be defined on this javascript engine",
              );
            }
            if ("value" in descriptor) {
              obj[prop] = Properties[prop].value;
            }
          }
        }
      }

      // 5. Return obj
      return obj;
    };
  })();

  function Status(parentEl) {
    this.status = UI_STATUS.ERROR;
    this.element = parentEl.add(
      "Panel { \
      alignChildren: 'fill', \
      grStatus: Group { \
        alignChildren: ['fill', 'center'], \
        gr: Group { \
          spacing: 6, \
          statusIcon: Group { \
            margins: [0, 4, 0, 0], \
            alignment: ['left', 'fill'], \
            icon: Group { \
              preferredSize: [8, 8], \
              alignment: ['left', 'top'], \
            }, \
          }, \
          grText: Group { \
            alignment: ['fill', 'top'], \
            alignChildren: ['left', 'top'], \
            orientation: 'column', \
            spacing: 0, \
          }, \
        }, \
      }, \
    }",
    );

    var grStatus = this.element.grStatus;
    var statusIcon = grStatus.gr.statusIcon.icon;

    statusIcon.onDraw = bind(function () {
      var g = statusIcon.graphics;
      var c = this.status === UI_STATUS.OK ? [0.1, 0.85, 0.1, 1] : [1, 0, 0, 1];
      var p = g.newPen(g.PenType.SOLID_COLOR, c, 2);

      if (this.status === UI_STATUS.OK) {
        g.moveTo(0, 3);
        g.lineTo(3, 6);
        g.lineTo(8, 0);
      } else {
        g.moveTo(0, 0);
        g.lineTo(8, 8);
        g.strokePath(p);

        g.currentPath = g.newPath();

        g.moveTo(8, 0);
        g.lineTo(0, 8);
      }

      g.strokePath(p);
    }, this);
  }

  Status.prototype.setStatusError = function () {
    this.set(UI_STATUS.ERROR);
  };

  Status.prototype.setStatusOK = function () {
    this.set(UI_STATUS.OK);
  };

  Status.prototype.set = function (status) {
    this.status = status;

    this.element.graphics.backgroundColor = this.element.graphics.newBrush(
      this.element.graphics.BrushType.SOLID_COLOR,
      this.status === UI_STATUS.OK ? [0.12, 0.2, 0.12, 1] : [0.2, 0.12, 0.12, 1],
    );
  };

  function PluginStatus(parentEl) {
    Status.call(this, parentEl);
    this.setPluginStatus();
  }

  PluginStatus.prototype = create(Status.prototype);

  PluginStatus.prototype.statusMessage = {};
  PluginStatus.prototype.statusMessage[ZOOM_PLUGIN_STATUS.NOT_FOUND] =
    "Zoom plug-in is not installed";
  PluginStatus.prototype.statusMessage[ZOOM_PLUGIN_STATUS.FOUND_NOT_INITIALIZED] =
    "Zoom plug-in is found but is not loaded by After Effects";
  PluginStatus.prototype.statusMessage[ZOOM_PLUGIN_STATUS.INITIALIZED_NOT_FOUND] =
    "Zoom plug-in is loaded by After Effects but cannot be found by the script.";
  PluginStatus.prototype.statusMessage[ZOOM_PLUGIN_STATUS.FINISHED] =
    "Zoom plug-in stopped working";
  PluginStatus.prototype.statusMessage[ZOOM_PLUGIN_STATUS.INITIALIZATION_ERROR] =
    "Error initializing Zoom plugin";
  PluginStatus.prototype.statusMessage[ZOOM_PLUGIN_STATUS.INITIALIZED] =
    "Zoom plug-in is installed";

  PluginStatus.prototype.setPluginStatus = function () {
    var statusChanged = this.pluginStatus !== zoomPlugin.status();

    if (statusChanged) {
      this.pluginStatus = zoomPlugin.status();
      this.pluginFound = zoomPlugin.isAvailable();
      var grStatus = this.element.grStatus;

      if (this.pluginFound) {
        this.setStatusOK();
      } else {
        this.setStatusError();
      }

      /** first, remove existing info */
      if (grStatus.gr.grText.children.length > 0) {
        var grText = grStatus.gr.grText;
        for (var i = grText.children.length - 1; i >= 0; i--) {
          grText.remove(i);
        }
      }

      if (this.element.grErrorInfo) {
        this.element.remove(this.element.grErrorInfo);
        this.element.grErrorInfo = undefined;
      }

      /** add new info */
      var txt = grStatus.gr.grText.add("StaticText {}");

      if (this.pluginStatus in this.statusMessage) {
        txt.text = this.statusMessage[this.pluginStatus];
      } else {
        txt.text = "Unknown plug-in status";
      }

      if (
        this.pluginStatus !== ZOOM_PLUGIN_STATUS.INITIALIZED &&
        this.pluginStatus !== ZOOM_PLUGIN_STATUS.NOT_FOUND
      ) {
        this.fillErrorInfo();
      }
    }

    return statusChanged;
  };

  PluginStatus.prototype.fillErrorInfo = function () {
    var grErrorInfo = this.element.add(
      "Group { \
      orientation: 'column', \
      alignChildren: ['center', 'top'], \
      txt: StaticText { \
        alignment: 'fill', \
        characters: 50, \
        properties: { \
          multiline: true, \
        }, \
      }, \
    }",
    );

    this.element.grErrorInfo = grErrorInfo;

    var errorText = "";
    if (zoomPlugin.foundEO) {
      try {
        errorText = zoomPlugin.getError();
      } catch (error) {
        /**/
      }
    }

    if (errorText) {
      grErrorInfo.txt.text = errorText;
      grErrorInfo.txt.characters = 50; // this fixes the height of the text
    } else if (zoomPlugin.status() === ZOOM_PLUGIN_STATUS.FOUND_NOT_INITIALIZED) {
      grErrorInfo.txt.text = "Try restarting After Effects.";
    } else if (zoomPlugin.status() === ZOOM_PLUGIN_STATUS.INITIALIZED_NOT_FOUND) {
      grErrorInfo.txt.text =
        "Please put the plug-in in one of the following locations:";

      var pluginsFoldersPaths = getPluginsFoldersPaths();

      if (pluginsFoldersPaths.common) {
        grErrorInfo.txt.text += "\n" + pluginsFoldersPaths.common;
      }

      if (pluginsFoldersPaths.individual) {
        grErrorInfo.txt.text += "\n" + pluginsFoldersPaths.individual;
      }
    }
  };

  function PluginStatusWithButton(parentEl) {
    PluginStatus.call(this, parentEl);
    var grStatus = this.element.grStatus;

    grStatus.btnPluginSettings = grStatus.add(
      "IconButton { \
      alignment: ['right', 'center'], \
      preferredSize: [130, 22], \
      title: 'Plug-in Settings ->', \
    }",
    );

    grStatus.btnPluginSettings.onClick = function () {
      var tabs = this.window.tabs;

      var pluginTab;
      for (var i = 0; i < tabs.children.length; i++) {
        if (tabs.children[i].text === "Plug-in") {
          pluginTab = tabs.children[i];
          break;
        }
      }

      tabs.selection = pluginTab;
    };
  }

  PluginStatusWithButton.prototype = create(PluginStatus.prototype);

  function Checkbox(parentEl, txt, containerGroup) {
    if (containerGroup) {
      containerGroup.spacing = 2;
    } else {
      containerGroup = parentEl.add("Group { spacing: 2 }");
    }

    this.element = containerGroup;
    this.element.check = this.element.add("Checkbox { preferredSize: [-1, 14] }");
    this.element.txt = this.element.add("StaticText { text: '" + txt + "' }");

    /** Make clicks on the text next to a check act as click on the check */
    this.element.addEventListener("click", function (event) {
      if (event.eventPhase === "target") {
        this.check.notify();
      }
    });
  }

  Checkbox.prototype.setValue = function (value) {
    this.element.check.value = value;
  };

  Checkbox.prototype.setOnClick = function (fn) {
    this.element.check.onClick = fn;
  };

  function TextLink(parentEl, text, linkAddress) {
    this.element = parentEl.add(
      "Group { \
      orientation: 'column', \
      spacing: 0, \
      alignChildren: 'left', \
      txt: StaticText {}, \
      line: Custom { \
        alignment: 'fill', \
        preferredSize: [-1, 2], \
      }, \
    }",
    );

    var textSize = this.element.txt.graphics.measureString(text);
    var textGraphics = this.element.txt.graphics;
    var lightBluePen = textGraphics.newPen(
      textGraphics.PenType.SOLID_COLOR,
      [65 / 255, 160 / 255, 1, 1],
      2,
    );
    var darkBluePen = textGraphics.newPen(
      textGraphics.PenType.SOLID_COLOR,
      [0.176, 0.411, 0.921, 1],
      2,
    );

    this.element.txt.text = text;
    this.element.txt.graphics.foregroundColor = darkBluePen;

    this.element.txt.addEventListener("click", function () {
      openURL(linkAddress);
    });

    this.element.txt.addEventListener(
      "mouseover",
      bind(function () {
        this.element.txt.graphics.foregroundColor = lightBluePen;
        this.element.line.mouseOver = true;
        this.element.line.notify("onDraw");
      }, this),
    );

    this.element.txt.addEventListener(
      "mouseout",
      bind(function () {
        this.element.txt.graphics.foregroundColor = darkBluePen;
        this.element.line.mouseOver = false;
        this.element.line.notify("onDraw");
      }, this),
    );

    this.element.line.onDraw = function () {
      var g = this.graphics;
      var p = this.mouseOver ? lightBluePen : darkBluePen;

      g.moveTo(0, 0);
      g.lineTo(textSize[0], 0);
      g.strokePath(p);
    };
  }

  function AboutWindow() {
    this.element = new Window(
      "dialog { \
      minimumSize: [300, 0], \
      alignChildren: ['fill', 'top'], \
      grTitle: Group { \
        spacing: 5, \
        orientation: 'column', \
        alignChildren: 'center', \
        txtVersion: StaticText {}, \
        txtDescription: StaticText { text: 'Improved zoom experience inside compositions.' }, \
        txtYear: StaticText { text: '2024' }, \
      }, \
      pnlReport: Panel { \
        spacing: 4, \
        alignChildren: 'fill', \
        txt: StaticText { text: 'Report Issues to:' }, \
        grGithubLink: Group {}, \
        grEmail: Group { \
          txt: StaticText { text: 'Email: ' }, \
          etxtEmail: EditText { \
            alignment: ['fill', 'center' ], \
            properties: { readonly: true }, \
            text: 'hello@motionprincess.com', \
          }, \
        }, \
      }, \
      pnlInfo: Panel { \
        orientation: 'row', \
        grName: Group { \
          orientation: 'column', \
          alignChildren: 'left', \
          alignment: ['left', 'top'], \
          spacing: 4, \
          txtName: StaticText { text: 'Developed by Denis Mozgovoy' }, \
        }, \
      }, \
      btnOK: IconButton { \
        alignment: 'right', \
        title: 'OK', \
        text: 'OK', \
        preferredSize: [100, 22], \
      }, \
    }",
      "Zoom About",
    );

    this.element.btnOK.onClick = function () {
      this.window.close();
    };

    this.element.grTitle.txtVersion.text = "Zoom " + VERSION;
    this.element.pnlInfo.grName.linkSite = new TextLink(
      this.element.pnlInfo.grName,
      "Motionprincess.com",
      "https://motionprincess.com/",
    );

    this.element.pnlInfo.grName.linkTwitter = new TextLink(
      this.element.pnlInfo.grName,
      "X / Twitter",
      "https://twitter.com/quismotion",
    );

    this.element.pnlReport.grGithubLink.linkGithubIssues = new TextLink(
      this.element.pnlReport.grGithubLink,
      "Github Issues",
      "https://github.com/QuisPic/ae-zoom/issues",
    );

    this.element.layout.layout(true);
    this.element.show();
  }

  function ExperimentalSettings(parentEl) {
    this.settingsOnStart = preferences.experimental;

    this.element = parentEl.add(
      "tab { \
      text: 'Experimental', \
      alignChildren: ['left', 'top'], \
      orientation: 'row', \
      margins: [12, 10, 0, 10], \
      gr: Group { \
        orientation: 'column', \
        alignment: ['fill', 'fill'], \
        alignChildren: 'fill', \
        grPluginStatus: Group { \
          alignChildren: ['fill', 'top'], \
        }, \
        pnlFixViewportPosition: Panel { \
          orientation: 'column', \
          alignChildren: 'left', \
          grCheck: Group {}, \
          txtDescription: StaticText {\
            text: 'Enabling this option fixes the automatic centering of the composition view when zoom is changed.', \
          },\
          pnlZoomAround: Panel { \
            alignment: 'fill', \
            alignChildren: 'left', \
            text: 'Mouse Wheel', \
            grZoomAround: Group { \
              txtZoomAround: StaticText {\
                text: 'When using mouse wheel, change zoom relative to: ', \
              }, \
              ddlistZoomPoint: DropDownList { \
                properties: { \
                  items: ['View Panel Center (AE default)', 'Cursor Position'],\
                }, \
              }, \
            }, \
          }, \
        }, \
        pnlDetectCursorInsideView: Panel { \
          orientation: 'column', \
          alignChildren: 'left', \
          grCheck: Group {}, \
          txtDescription: StaticText { \
            text: 'If enabled, Zoom key bindings that include mouse events will be captured only when the mouse cursor is inside a viewport.', \
            characters: 55, \
            properties: { multiline: true }, \
          },\
        }, \
        pnlWarning: Panel { \
          alignChildren: 'left', \
          spacing: 1, \
          txt0: StaticText {}, \
          txt1: StaticText {}, \
          txt2: StaticText {}, \
          grButtons: Group { \
            margins: [0, 10, 0, 0], \
            alignment: 'right', \
            btnReset: IconButton { \
              title: 'Reset Experimental Settings', \
              preferredSize: [-1, 22], \
            }, \
            btnContacts: IconButton { \
              title: 'Contacts', \
              preferredSize: [-1, 22], \
            }, \
          }, \
        }, \
      }, \
    }",
    );

    var pnlDetectCursorInsideView = this.element.gr.pnlDetectCursorInsideView;
    var pnlFixViewportPosition = this.element.gr.pnlFixViewportPosition;
    var pnlWarning = this.element.gr.pnlWarning;

    pnlDetectCursorInsideView.grCheck = new Checkbox(
      pnlDetectCursorInsideView,
      "Change zoom only when cursor is inside a viewport",
      pnlDetectCursorInsideView.grCheck,
    );

    pnlFixViewportPosition.grCheck = new Checkbox(
      pnlFixViewportPosition,
      "Maintain View position after zooming",
      pnlFixViewportPosition.grCheck,
    );

    this.readSettingsFrom(preferences.experimental);

    /** Show plug-in status if plug-in is not found */
    if (zoomPlugin.status() !== ZOOM_PLUGIN_STATUS.INITIALIZED) {
      this.addStatus();
    } else {
      this.deleteStatus();
    }

    pnlDetectCursorInsideView.grCheck.setOnClick(bind(this.saveAll, this));

    pnlFixViewportPosition.grCheck.setOnClick(
      bind(function () {
        var pnlFixViewportPosition = this.element.gr.pnlFixViewportPosition;

        pnlFixViewportPosition.pnlZoomAround.enabled =
          pnlFixViewportPosition.grCheck.element.check.value;

        this.saveAll();
      }, this),
    );

    pnlFixViewportPosition.pnlZoomAround.grZoomAround.ddlistZoomPoint.onChange =
      bind(this.saveAll, this);

    pnlWarning.txt0.text = "Please note that these settings are experimental.";
    pnlWarning.txt1.text =
      "Experimental settings may not work as described or may even cause After Effects to crash.";
    pnlWarning.txt2.text =
      "If you experience such issues, please report to the author.";

    pnlWarning.grButtons.btnContacts.onClick = function () {
      windows.new(AboutWindow);
    };

    pnlWarning.grButtons.btnReset.onClick = bind(function () {
      this.readSettingsFrom(DEFAULT_SETTINGS.experimental);
      this.saveAll();
    }, this);

    pnlWarning.graphics.backgroundColor = this.element.graphics.newBrush(
      this.element.graphics.BrushType.SOLID_COLOR,
      [0.19, 0.19, 0, 1],
    );
  }

  ExperimentalSettings.prototype.readSettingsFrom = function (settingsObj) {
    var pnlDetectCursorInsideView = this.element.gr.pnlDetectCursorInsideView;
    var pnlFixViewportPosition = this.element.gr.pnlFixViewportPosition;

    pnlDetectCursorInsideView.grCheck.setValue(
      settingsObj.detectCursorInsideView,
    );

    pnlFixViewportPosition.grCheck.setValue(
      settingsObj.fixViewportPosition.enabled,
    );

    pnlFixViewportPosition.pnlZoomAround.grZoomAround.ddlistZoomPoint.selection =
      settingsObj.fixViewportPosition.zoomAround;

    pnlFixViewportPosition.pnlZoomAround.enabled =
      settingsObj.fixViewportPosition.enabled;
  };

  ExperimentalSettings.prototype.addStatus = function () {
    var grPluginStatus = this.element.gr.grPluginStatus;
    grPluginStatus.pluginStatusPanel = new PluginStatusWithButton(grPluginStatus);

    var grText = grPluginStatus.pluginStatusPanel.element.grStatus.gr.grText;
    var statusText = grText.children[0].text;

    grText.children[0].text = "Experimental settings are not available:";
    grText.add("StaticText { text: '" + statusText + "' }");

    this.element.gr.pnlDetectCursorInsideView.enabled = false;
    this.element.gr.pnlFixViewportPosition.enabled = false;
  };

  ExperimentalSettings.prototype.deleteStatus = function () {
    if (this.element.gr.grPluginStatus) {
      this.element.gr.remove(this.element.gr.grPluginStatus);
      this.element.gr.grPluginStatus = undefined;
    }
  };

  ExperimentalSettings.prototype.reloadStatus = function () {
    if (this.element.gr.grPluginStatus) {
      var pluginStatusPanel = this.element.gr.grPluginStatus.pluginStatusPanel;

      if (pluginStatusPanel) {
        var statusChanged = pluginStatusPanel.setPluginStatus();

        if (statusChanged) {
          if (pluginStatusPanel.pluginStatus === ZOOM_PLUGIN_STATUS.INITIALIZED) {
            this.deleteStatus();
            this.element.gr.pnlDetectCursorInsideView.enabled = true;
            this.element.gr.pnlFixViewportPosition.enabled = true;
          }

          this.element.layout.layout(true);
          this.element.layout.resize();
        }
      }
    }
  };

  ExperimentalSettings.prototype.saveAll = function () {
    preferences.save("experimental", {
      detectCursorInsideView:
        this.element.gr.pnlDetectCursorInsideView.grCheck.element.check.value,
      fixViewportPosition: {
        enabled:
          this.element.gr.pnlFixViewportPosition.grCheck.element.check.value,
        zoomAround:
          this.element.gr.pnlFixViewportPosition.pnlZoomAround.grZoomAround
            .ddlistZoomPoint.selection.index,
      },
    });
  };

  ExperimentalSettings.prototype.cancel = function () {
    if (this.settingsOnStart !== preferences.experimental) {
      preferences.save("experimental", this.settingsOnStart);
    }
  };

  function ScreenWindow(numberValue, screenBounds, onMouseMoveFn, onCloseFn) {
    this.element = new Window(
      "palette { \
      alignChildren: ['fill','fill'], \
      margins: 0, \
      properties: { borderless: true } \
      gr: Button {}, \
    }",
    );

    this.element.opacity = AE_OS === OS.WIN ? 0.01 : 0;
    this.element.size = [200, 200];

    // remove all drawing on the button
    this.element.gr.onDraw = function () {};

    // make the window move after the mouse cursor
    this.element.gr.addEventListener("mousemove", function (event) {
      this.window.location = [
        event.screenX - this.window.size[0] / 2,
        event.screenY - this.window.size[1] / 2,
      ];

      onMouseMoveFn(event);
    });

    // if we move the cursor too fast the cursor may go out of window bounds
    this.element.gr.addEventListener("mouseout", function (event) {
      if (event.eventPhase === "target") {
        onCloseFn();
      }
    });

    this.element.gr.onClick = function () {
      onCloseFn();
    };

    this.element.gr.addEventListener("mouseup", function (event) {
      if (event.eventPhase === "target") {
        onCloseFn();
      }
    });

    this.element.show();
    this.element.location = [
      numberValue.lastMousePosition[0] - this.element.size[0] / 2,
      numberValue.lastMousePosition[1] - this.element.size[1] / 2,
    ];
  }

  function FloatEditText(parentEl, initTextValue) {
    this.parentEl = parentEl;
    this.blurTaskId = undefined;

    this.element = parentEl.add(
      "EditText { \
      active: true, \
      alignment: 'left', \
      text: '" +
        (initTextValue || "") +
        "' \
    }",
    );

    this.element.onChange = bind(function () {
      if (typeof this.onChangeFn === "function") {
        this.onChangeFn(this.element.text);
      }
    }, this);

    /** Increment number value using arrow keys */
    this.element.addEventListener(
      "keyup",
      bind(function (event) {
        if (event.eventPhase === "target") {
          if (event.keyName === "Up") {
            event.preventDefault();
            var val = parseFloat(this.element.text);

            if (!isNaN(val)) {
              this.element.text = val + 1;
            }
          } else if (event.keyName === "Down") {
            event.preventDefault();
            val = parseFloat(this.element.text);

            if (!isNaN(val)) {
              this.element.text = val - 1;
            }
          }
        }
      }, this),
    );

    /** Put onDeactivate handler in the gloval scope
     * to later call this handler from a task. */
    $.global.__zoom_blur_handler = bind(function () {
      /** check if this element has put the task */
      if (!this.blurTaskId) {
        return;
      }

      if (typeof this.onBlurFn === "function") {
        this.onBlurFn();
      }

      this.removeSelf();
    }, this);

    /** If a user presses Escape it may stop any code execution on Windows. In this case
     * the callback won't finish. Putting the callback in a task fixes this behavior. */
    this.element.onDeactivate = bind(function () {
      this.blurTaskId = app.scheduleTask(
        "$.global.__zoom_blur_handler()",
        0,
        false,
      );
    }, this);
  }

  FloatEditText.prototype.setValue = function (txt) {
    this.element.text = txt;
  };

  FloatEditText.prototype.setSize = function (size) {
    this.element.size = size;
  };

  FloatEditText.prototype.setLocation = function (location) {
    this.element.location = location;
  };

  FloatEditText.prototype.setOnChangeFn = function (fn) {
    this.onChangeFn = fn;
  };

  FloatEditText.prototype.setOnBlurFn = function (fn) {
    this.onBlurFn = fn;
  };

  FloatEditText.prototype.removeSelf = function () {
    if (this.element && isValid(this.element)) {
      this.parentEl.remove(this.element);
    }
  };

  function NumberValue(
    parentEl,
    unitsSymbol,
    initValue,
    minValue,
    maxValue,
    onChangeFn,
    onScrubStartFn,
    onScrubEndFn,
    helpTip,
  ) {
    this.w =
      parentEl instanceof Window || parentEl instanceof Panel
        ? parentEl
        : parentEl.window;
    this.parentEl = parentEl;
    this.minValue = minValue;
    this.maxValue = maxValue;
    this.onChangeFn = onChangeFn;
    this.screenWin = undefined;
    this.lastMousePosition = [0, 0];

    this.element = parentEl.add(
      "Group { \
      orientation: 'stack', \
      alignChildren: ['left', 'center'], \
      grValue: Group { \
        alignChildren: ['left', 'fill'], \
        spacing: 0, \
        grText: Group { \
          margins: [6, 2, 0, 0], \
          orientation: 'stack', \
          alignChildren: ['fill', 'fill'], \
          grUnderline: Group { visible: false }, \
          txtValue: StaticText { \
            text: '0', \
            helpTip: '" +
        (helpTip || "") +
        "' \
          }, \
        }, \
        grSpace: Group { preferredSize: [2, -1], alignment: ['fill', 'fill'] }, \
        txtUnits: StaticText { text: '" +
        unitsSymbol +
        "' }, \
      }, \
    }",
    );

    var thisNumberValue = this;
    var grValue = this.element.grValue;
    var grText = grValue.grText;
    var txtUnits = grValue.txtUnits;
    var grSpace = grValue.grSpace;
    var txtValue = grText.txtValue;
    var grUnderline = grText.grUnderline;
    var isMouseDown = false;

    var g = txtUnits.graphics;
    var lightPen = g.newPen(g.PenType.SOLID_COLOR, [0.75, 0.75, 0.75, 1], 1);
    var darkPen = g.newPen(g.PenType.SOLID_COLOR, [0.55, 0.55, 0.55, 1], 1);
    var bluePen = g.newPen(g.PenType.SOLID_COLOR, BLUE_COLOR, 2);

    if (initValue !== undefined && !isNaN(parseFloat(initValue))) {
      txtValue.text = parseFloat(initValue);
    }

    txtValue.graphics.foregroundColor = bluePen;
    this.element.minimumSize = this.element.graphics.measureString("00000000");

    grValue.addEventListener(
      "mousedown",
      bind(function (event) {
        if (event.eventPhase === "target") {
          isMouseDown = true;
          this.lastMousePosition = [event.screenX, event.screenY];
        }
      }, this),
    );

    grValue.addEventListener(
      "mouseup",
      bind(function (event) {
        if (event.eventPhase === "target" && isMouseDown) {
          isMouseDown = false;

          var editText = new FloatEditText(this.element, txtValue.text);

          editText.setSize([
            editText.element.graphics.measureString("000000")[0],
            thisNumberValue.element.size[1],
          ]);

          editText.setOnChangeFn(
            bind(function (txt) {
              var newValue = parseFloat(txt);

              if (!isNaN(newValue)) {
                this.setValue(newValue);
                this.onChange();
                onScrubEndFn();
              }
            }, this),
          );

          editText.setOnBlurFn(
            bind(function () {
              grValue.show();
            }, this),
          );

          grValue.hide();
          this.element.layout.layout(true);
        }
      }, this),
    );

    grValue.addEventListener(
      "mousemove",
      bind(function (event) {
        if (
          event.eventPhase === "target" &&
          isMouseDown &&
          Math.abs(event.screenX - this.lastMousePosition[0]) >= 3
        ) {
          if (typeof onScrubStartFn === "function") {
            onScrubStartFn();
          }

          grUnderline.show();

          var onMouseMoveFn = bind(function (event) {
            if (event.eventPhase === "target") {
              var mouseDistance = Math.floor(
                event.screenX - this.lastMousePosition[0],
              );

              var ctrlKey = AE_OS === OS.WIN ? event.ctrlKey : event.metaKey;
              var shiftKey = event.shiftKey;

              if (Math.abs(mouseDistance) >= 1) {
                if (shiftKey) {
                  mouseDistance *= 10;
                } else if (ctrlKey) {
                  mouseDistance /= 10;
                }

                var newValue = this.getValue() + mouseDistance;

                if (!ctrlKey) {
                  newValue = makeDivisibleBy(newValue, 1, mouseDistance < 0);
                }

                if (shiftKey) {
                  newValue = makeDivisibleBy(newValue, 10, mouseDistance < 0);
                }

                this.setValue(newValue);
                this.onChange();
                this.lastMousePosition = [event.screenX, event.screenY];
              }
            }
          }, this);

          var onCloseFn = bind(function () {
            if (this.screenWin && this.screenWin.element.visible) {
              this.screenWin.element.close();
            }

            grUnderline.hide();

            if (typeof onScrubEndFn === "function") {
              onScrubEndFn();
            }
          }, this);

          this.screenWin = undefined;
          for (var i = 0; i < $.screens.length; i++) {
            // if the screen contains the cursor
            if (
              this.lastMousePosition[0] >= $.screens[i].left &&
              this.lastMousePosition[0] <= $.screens[i].right &&
              this.lastMousePosition[1] >= $.screens[i].top &&
              this.lastMousePosition[1] <= $.screens[i].bottom
            ) {
              this.screenWin = new ScreenWindow(
                this,
                $.screens[i],
                onMouseMoveFn,
                onCloseFn,
              );

              break;
            }
          }

          isMouseDown = false;
        }
      }, this),
    );

    grText.addEventListener("mouseover", function () {
      txtUnits.graphics.foregroundColor = lightPen;
    });

    grText.addEventListener("mouseout", function () {
      txtUnits.graphics.foregroundColor = darkPen;
    });

    // add fully transparent color to this empty group so that the parent group
    // has no "holes" on which the "mouseover" event is not fired
    grSpace.graphics.backgroundColor = grSpace.graphics.newBrush(
      grSpace.graphics.BrushType.SOLID_COLOR,
      [0, 0, 0, 0],
    );

    grUnderline.onDraw = function () {
      var g = this.graphics;

      g.moveTo(0, this.size[1]);
      g.lineTo(this.size[0], this.size[1]);
      g.strokePath(bluePen);
    };
  }

  NumberValue.prototype.getValue = function () {
    return parseFloat(this.element.grValue.grText.txtValue.text);
  };

  NumberValue.prototype.setValue = function (val) {
    if (this.minValue !== undefined) {
      val = val < this.minValue ? this.minValue : val;
    }

    if (this.maxValue !== undefined) {
      val = val > this.maxValue ? this.maxValue : val;
    }

    var txt = this.element.grValue.grText.txtValue;

    txt.text = val;
    txt.size = txt.graphics.measureString(val);

    this.element.layout.layout(true);
  };

  NumberValue.prototype.onChange = function () {
    if (typeof this.onChangeFn === "function") {
      this.onChangeFn(this.getValue());
    }
  };

  var indexOf = function (array, searchElement, fromIndex) {
    // 1. Let o be the result of calling ToObject passing
    //    the this value as the argument.
    if (array === void 0 || array === null) {
      throw new TypeError("Array.prototype.indexOf called on null or undefined");
    }

    var k;
    var o = Object(array);

    // 2. Let lenValue be the result of calling the Get
    //    internal method of o with the argument "length".
    // 3. Let len be ToUint32(lenValue).
    var len = o.length >>> 0;

    // 4. If len is 0, return -1.
    if (len === 0) {
      return -1;
    }

    // 5. If argument fromIndex was passed let n be
    //    ToInteger(fromIndex); else let n be 0.
    var n = +fromIndex || 0;

    if (Math.abs(n) === Infinity) {
      n = 0;
    }

    // 6. If n >= len, return -1.
    if (n >= len) {
      return -1;
    }

    // 7. If n >= 0, then Let k be n.
    // 8. Else, n<0, Let k be len - abs(n).
    //    If k is less than 0, then let k be 0.
    k = Math.max(n >= 0 ? n : len - Math.abs(n), 0);

    // 9. Repeat, while k < len
    while (k < len) {
      // a. Let Pk be ToString(k).
      //   This is implicit for LHS operands of the in operator
      // b. Let kPresent be the result of calling the
      //    HasProperty internal method of o with argument Pk.
      //   This step can be combined with c
      // c. If kPresent is true, then
      //    i.  Let elementK be the result of calling the Get
      //        internal method of o with the argument ToString(k).
      //   ii.  Let same be the result of applying the
      //        Strict Equality Comparison Algorithm to
      //        searchElement and elementK.
      //  iii.  If same is true, return k.
      if (k in o && o[k] === searchElement) {
        return k;
      }
      k++;
    }
    return -1;
  };

  var arrowUpIcon =
    '\u0089PNG\r\n\x1A\n\x00\x00\x00\rIHDR\x00\x00\x00\x0F\x00\x00\x00\x0F\x04\x03\x00\x00\x00\u00C9\u00F8\u0088y\x00\x00\x00$zTXtCreator\x00\x00\b\u0099sL\u00C9OJUpL+I-RpMKKM.)\x06\x00Az\x06\u00CEjz\x15\u00C5\x00\x00\x00\tpHYs\x00\x00\x00\x01\x00\x00\x00\x01\x00O%\u00C4\u00D6\x00\x00\x00\x1BPLTEGpL\u008A\u008A\u008A\u008A\u008A\u008A\u008A\u008A\u008A\u008A\u008A\u008A\u008A\u008A\u008A\u008A\u008A\u008A\u008A\u008A\u008A\u008A\u008A\u008AR\u00F2}\u009D\x00\x00\x00\btRNS\x00\x0FP\u00F4E"\u00F10L\u00E8\x06\u00F3\x00\x00\x001IDAT\b\u00D7c`\u00C0\x06\x18a\fg\x07\b\u00CD\u0092\u0091\x04a(k(+\u0080hV#\t\x16s\u00B0H\x00\u0087@\x00D\u008EC\u0080\u0081x\x06#\u008A\u0085\x00\x1EI\x03\u009C\u0080\u00A6\u00CCK\x00\x00\x00\x00IEND\u00AEB`\u0082';

  var arrowDownIcon =
    "\u0089PNG\r\n\x1A\n\x00\x00\x00\rIHDR\x00\x00\x00\x0F\x00\x00\x00\x0F\x04\x03\x00\x00\x00\u00C9\u00F8\u0088y\x00\x00\x00$zTXtCreator\x00\x00\b\u0099sL\u00C9OJUpL+I-RpMKKM.)\x06\x00Az\x06\u00CEjz\x15\u00C5\x00\x00\x00\tpHYs\x00\x00\x00\x01\x00\x00\x00\x01\x00O%\u00C4\u00D6\x00\x00\x00\x1EPLTEGpL\u008A\u008A\u008A\u008A\u008A\u008A\u008A\u008A\u008A\u008A\u008A\u008A\u008A\u008A\u008A\u008A\u008A\u008A\u008A\u008A\u008A\u008A\u008A\u008A\u008A\u008A\u008A\u00E3\x0B\u00E2\u00C1\x00\x00\x00\ttRNS\x00\x10S#\u00F4D\u00F14\f3\u0082\u00B1\u00F4\x00\x00\x000IDAT\b\u00D7c`\u00C0\x06\u0098a\fN\x01\u00E2\x19\x06\u009C\x02\x06`\u00CDN\u009C\u00A2\u00EE`\u00910M5\x050\u00835\u00D3\t\u00AA\u00B8D\x01\u00CA\u00E0@\u00B1\x10\x00\u00AA\u00E0\x03\u00B5\u00F4\f\u00C7H\x00\x00\x00\x00IEND\u00AEB`\u0082";

  function Row(list) {
    this.list = list;
    this.columns = [];
    this.minSize = [0, 0];
    this.columnMargins = undefined;
    this.columnAlignments = undefined;
    this.colorSelected = [0.27, 0.27, 0.27, 1];
    this.colorDeselected = [0.113, 0.113, 0.113, 1];
    this.editing = false;

    this.element = list.grRows.add(
      "Group { \
      alignment: ['fill', 'top'], \
      alignChildren: ['left', 'fill'], \
      spacing: 0, \
    }",
    );

    this.setBgColor([0.113, 0.113, 0.113, 1]);
  }

  Row.prototype.onClickHandler = undefined;
  Row.prototype.onDoubleClickHandler = undefined;
  Row.prototype.fillHandler = undefined;
  Row.prototype.editHandler = undefined;
  Row.prototype.abortEditHandler = undefined;

  Row.prototype.setOnAllColumns = function (key, value) {
    for (var i = 0; i < this.columns.length; i++) {
      this.columns[i][key] = value;
    }
  };

  Row.prototype.setColumnWidths = function (widths) {
    for (var i = 0; i < this.columns.length; i++) {
      if (widths[i] !== undefined) {
        this.columns[i].minimumSize = [widths[i], 0];
      }
    }
  };

  Row.prototype.setMinSize = function (minSize) {
    this.minSize = minSize;
    this.element.minimumSize = minSize;
    this.setOnAllColumns("minimumSize", this.minSize);
  };

  Row.prototype.setColumnMargins = function (columnMargins) {
    this.columnMargins = columnMargins;
    this.setOnAllColumns("margins", columnMargins);
  };

  Row.prototype.add = function (element) {
    var columnGroup = this.element.add(
      "Group { \
      alignChildren: ['fill', 'fill'], \
    }",
    );

    columnGroup.minimumSize = this.minSize;

    if (typeof element === "string") {
      columnGroup.element = columnGroup.add(element);
    } else if (typeof element === "function") {
      columnGroup.element = element(columnGroup);
    }

    this.columns.push(columnGroup);

    return columnGroup;
  };

  Row.prototype.edit = function (content) {
    var indInList = indexOf(this.list.rows, this);
    if (indInList !== -1) {
      this.list.contents[indInList] = content;

      if (this.list.onChangeHandler) {
        this.list.onChangeHandler();
      }
    }

    this.clear();

    if (typeof this.fillHandler === "function") {
      this.fillHandler(content);
    }

    if (this.list.columnWidths.length > 0) {
      this.setColumnWidths(this.list.columnWidths);
    }

    this.element.layout.layout(true);
  };

  Row.prototype.clear = function () {
    for (var i = 0; i < this.columns.length; i++) {
      if (this.columns[i] && isValid(this.columns[i])) {
        this.element.remove(this.columns[i]);
      }
    }

    this.columns.length = 0;
  };

  Row.prototype.setBgColor = function (color) {
    if (color) {
      this.element.graphics.backgroundColor = this.element.graphics.newBrush(
        this.element.graphics.BrushType.SOLID_COLOR,
        color,
      );
    }
  };

  Row.prototype.setColumnsBgColor = function (color) {
    if (color) {
      for (var i = 0; i < this.columns.length; i++) {
        this.columns[i].graphics.backgroundColor = this.element.graphics.newBrush(
          this.element.graphics.BrushType.SOLID_COLOR,
          color,
        );
      }
    }
  };

  Row.prototype.onClick = function (event) {
    if (this.onClickHandler) {
      var canCallDoubleClick = this.onClickHandler(event);
    }

    if (
      canCallDoubleClick !== false &&
      event.detail === 2 &&
      event.button === 0 &&
      this.onDoubleClickHandler
    ) {
      this.onDoubleClickHandler(event);
    }
  };

  Row.prototype.removeSelf = function () {
    if (this.element && isValid(this.element)) {
      this.element.parent.remove(this.element);
    }
  };

  /** override this function if you need custom colors */
  Row.prototype.getColorSelected = function () {
    return this.colorSelected;
  };

  /** override this function if you need custom colors */
  Row.prototype.getColorDeselected = function () {
    return this.colorDeselected;
  };

  function BasicList(parentEl) {
    this.RowClass = Row;
    this.ColumnNamesClass = undefined;
    this.columnNamesRow = undefined;
    this.contents = [];
    this.rows = [];
    this.columnWidths = [];

    this.parentGroup = parentEl.add(
      "Group { \
      orientation: 'row', \
      alignChildren: ['fill', 'top'], \
      gr: Group { \
        orientation: 'stack', \
        alignment: ['fill', 'fill'], \
        alignChildren: 'fill', \
        grBorder: Group { visible: false }, \
        grElement: Group { \
          margins: 1, \
        }, \
      }, \
    }",
    );

    this.element = this.parentGroup.gr.grElement.add(
      "Panel { \
      margins: 0, \
      spacing: 0, \
      alignment: ['fill', 'fill'], \
      orientation: 'row', \
      grList: Group { \
        orientation: 'stack', \
        alignment: ['fill', 'fill'], \
        alignChildren: 'fill', \
        grRows: Group { \
          orientation: 'column', \
          margins: [0, 0, 0, 1], \
          alignment: ['fill', 'top'], \
          alignChildren: ['fill', 'top'], \
          spacing: 1, \
        }, \
      }, \
    }",
    );

    this.grRows = this.element.grList.grRows;

    this.element.graphics.backgroundColor = this.element.graphics.newBrush(
      this.element.graphics.BrushType.SOLID_COLOR,
      [0.113, 0.113, 0.113, 1],
    );

    this.element.grList.grRows.graphics.backgroundColor =
      this.element.graphics.newBrush(
        this.element.graphics.BrushType.SOLID_COLOR,
        [0.164, 0.164, 0.164, 1],
      );

    this.element.window.addEventListener(
      "show",
      bind(function () {
        this.refresh();
      }, this),
    );
  }

  BasicList.prototype.addRow = function (index) {
    var row = new this.RowClass(this);

    if (typeof row.fillHandler === "function") {
      row.fillHandler(this.contents[index]);
    }

    if (this.columnWidths.length > 0) {
      row.setColumnWidths(this.columnWidths);
    }

    this.rows.push(row);
    return row;
  };

  BasicList.prototype.build = function (fromIndex) {
    fromIndex = fromIndex === undefined ? 0 : fromIndex;

    for (var i = fromIndex; i < this.contents.length; i++) {
      this.addRow(i);
    }
  };

  BasicList.prototype.refresh = function () {
    this.element.layout.layout(true);
    this.resizeColumns();
    this.element.layout.resize();
  };

  BasicList.prototype.resizeColumns = function () {
    var fillMaxWidths = bind(function (row) {
      for (var k = 0; k < row.columns.length; k++) {
        if (
          !this.columnWidths[k] ||
          row.columns[k].size.width > this.columnWidths[k]
        ) {
          this.columnWidths[k] = row.columns[k].size.width;
        }
      }
    }, this);

    if (this.columnNamesRow) {
      fillMaxWidths(this.columnNamesRow);
    }

    for (var i = 0; i < this.rows.length; i++) {
      fillMaxWidths(this.rows[i]);
    }

    if (this.columnNamesRow) {
      this.columnNamesRow.setColumnWidths(this.columnWidths);
    }

    for (i = 0; i < this.rows.length; i++) {
      this.rows[i].setColumnWidths(this.columnWidths);
    }
  };

  BasicList.prototype.addColumnNames = function (names) {
    if (this.ColumnNamesClass) {
      this.columnNamesRow = new this.ColumnNamesClass(this);
      this.columnNamesRow.fillHandler(names);
    }
  };

  /** Extends BasicList */
  function List(parentEl) {
    BasicList.call(this, parentEl);

    this.active = false;
    this.editing = false;
    this.lastClickEventTime = undefined;
    this.selectedRows = [];

    // required for range selection with the Shift key
    this.lastClickedRowInd = undefined;

    // fn to call when adding a new row
    this.addRowHandler = undefined;

    this.parentGroup.grButtons = this.parentGroup.add(
      "Group { \
      alignment: ['right', 'fill'], \
      orientation: 'column', \
      spacing: 5, \
      btnNew: IconButton { title: 'New', preferredSize: [90, 22] }, \
      btnEdit: IconButton { title: 'Edit', preferredSize: [90, 22] }, \
      btnDelete: IconButton { title: 'Delete', preferredSize: [90, 22] }, \
      btnMoveUp: IconButton { \
        preferredSize: [90, 22], \
        alignment: ['right', 'bottom'], \
        helpTip: 'Move Up', \
      }, \
      btnMoveDown: IconButton { \
        preferredSize: [90, 22], \
        alignment: ['right', 'bottom'], \
        helpTip: 'Move Down', \
      }, \
    }",
    );

    this.setButtonsPosition(List.BUTTONS_POSITION.RIGHT);

    if (!this.element.window.__listsArray) {
      this.element.window.__listsArray = [];
    }
    this.element.window.__listsArray.push(this);

    this.parentGroup.gr.grBorder.visible = this.active;
    this.parentGroup.gr.grBorder.onDraw = function () {
      var r = 3; // round corner radius
      var g = this.graphics;
      var b = g.newBrush(g.BrushType.SOLID_COLOR, BLUE_COLOR);
      var s = this.size;

      drawRoundRect(r, g, b, undefined, s);
    };

    /** pass click events to our custom handler */
    this.element.grList.addEventListener(
      "mousedown",
      bind(function (event) {
        event.preventDefault();
        this.onClick(event);

        this.lastClickEventTime = event.timeStamp.getTime();
        this.activate();
      }, this),
      // true,
    );

    this.element.window.addEventListener("mousedown", function (event) {
      for (var i = 0; i < this.__listsArray.length; i++) {
        var list = this.__listsArray[i];
        if (
          event.timeStamp.getTime() !== list.lastClickEventTime &&
          indexOf(list.parentGroup.grButtons.children, event.target) === -1
        ) {
          list.deactivate();
          list.deselectAllRows();
        }
      }
    });

    this.element.window.addEventListener(
      "keyup",
      bind(function (event) {
        if (this.active && event.eventPhase === "target") {
          if (event.keyName === "Delete") {
            this.deleteSelectedRows();
            this.refresh();
          } else if (event.keyName === "Enter") {
            this.editSelectedRow();
          }
        }
      }, this),
    );

    this.parentGroup.grButtons.btnNew.onClick = bind(function () {
      this.new();
    }, this);

    this.parentGroup.grButtons.btnEdit.onClick = bind(function () {
      this.editSelectedRow();
    }, this);

    this.parentGroup.grButtons.btnDelete.onClick = bind(function () {
      var msg =
        this.selectedRows.length > 1
          ? "Delete selected items?"
          : "Delete this item?";
      var confirmed = confirm(msg, true);
      if (confirmed) {
        this.deleteSelectedRows();
        this.refresh();
      }
    }, this);

    this.parentGroup.grButtons.btnMoveUp.icon = arrowUpIcon;
    this.parentGroup.grButtons.btnMoveDown.icon = arrowDownIcon;

    this.parentGroup.grButtons.btnMoveUp.onClick = bind(function () {
      this.moveSelectedRows(List.MOVE_ROW_DIRECTION.UP);
    }, this);
    this.parentGroup.grButtons.btnMoveDown.onClick = bind(function () {
      this.moveSelectedRows(List.MOVE_ROW_DIRECTION.DOWN);
    }, this);
  }

  List.BUTTONS_POSITION = {
    LEFT: 0,
    RIGHT: 1,
    BOTTOM: 2,
  };

  List.MOVE_ROW_DIRECTION = {
    UP: 0,
    DOWN: 1,
  };

  List.prototype = create(BasicList.prototype);
  List.prototype.onChangeHandler = undefined;
  List.prototype.editHandler = undefined;
  List.prototype.abortEditHandler = undefined;

  List.prototype.setButtonsPosition = function (pos) {
    if (pos === List.BUTTONS_POSITION.RIGHT) {
      this.parentGroup.orientation = "row";
      this.parentGroup.grButtons.orientation = "column";
      this.parentGroup.grButtons.alignment = ["right", "fill"];
    } else if (pos === List.BUTTONS_POSITION.BOTTOM) {
      this.parentGroup.orientation = "column";
      this.parentGroup.grButtons.orientation = "row";
      this.parentGroup.grButtons.alignment = ["left", "bottom"];
    }
  };

  List.prototype.activate = function () {
    if (!this.active) {
      this.active = true;
      this.parentGroup.gr.grBorder.visible = true;
    }
  };

  List.prototype.deactivate = function () {
    if (this.active) {
      this.active = false;
      this.parentGroup.gr.grBorder.visible = false;
    }
  };

  List.prototype.setSize = function (size) {
    this.element.grList.size = size;
  };

  List.prototype.setMaxSize = function (maxSize) {
    this.element.grList.maximumSize = maxSize;
  };

  List.prototype.setMinSize = function (minSize) {
    this.element.grList.minimumSize = minSize;
  };

  List.prototype.new = function () {
    if (this.editing && this.abortEditHandler) {
      this.abortEditHandler();
    }

    for (var i = 0; i < this.rows.length; i++) {
      if (this.rows[i].editing && this.rows[i].abortEditHandler) {
        this.rows[i].abortEditHandler();
      }
    }

    // this.contents.push(undefined);
    var newRow = this.addRow();

    if (this.editHandler) {
      this.editHandler(this.rows.length - 1);
    }

    if (newRow.editHandler) {
      this.refresh();
      this.scrollToBottom();
      this.deselectAllRows();
      this.selectRow(this.rows.length - 1);

      newRow.editHandler(this);
    }
  };

  List.prototype.moveSelectedRows = function (direction) {
    /** if there is less than 2 rows there's nowhere to move */
    if (this.rows.length < 2) {
      return;
    }

    if (this.selectedRows.length === 0) {
      return;
    }

    this.selectedRows.sort(function (a, b) {
      return a - b;
    });

    var numRows = this.selectedRows.length;
    var placePos = 0;
    var updateFromInd = 0;
    if (direction === List.MOVE_ROW_DIRECTION.UP) {
      placePos = this.selectedRows[0] - 1;
      placePos = placePos < 0 ? 0 : placePos;
      updateFromInd = placePos;
    } else if (direction === List.MOVE_ROW_DIRECTION.DOWN) {
      placePos =
        this.selectedRows[this.selectedRows.length - 1] + 1 - (numRows - 1);
      placePos =
        placePos > this.rows.length - numRows
          ? this.rows.length - numRows
          : placePos;
      updateFromInd = this.selectedRows[0];
    }

    var removedContent = [];
    for (i = 0; i < this.selectedRows.length; i++) {
      removedContent.push(this.contents[this.selectedRows[i]]);
    }

    for (var i = this.selectedRows.length - 1; i >= 0; i--) {
      var numRemove = 1;

      /** while prev selected row is exactly one row above */
      while (
        i - 1 >= 0 &&
        this.selectedRows[i] - this.selectedRows[i - 1] === 1
      ) {
        numRemove++;
        i--;
      }

      this.contents.splice(this.selectedRows[i], numRemove);
    }

    if (direction === List.MOVE_ROW_DIRECTION.UP) {
      removedContent = removedContent.concat(this.contents.slice(updateFromInd));
    } else if (direction === List.MOVE_ROW_DIRECTION.DOWN) {
      var newRemovedContent = this.contents.slice(updateFromInd);
      Array.prototype.splice.apply(
        newRemovedContent,
        [placePos - updateFromInd, 0].concat(removedContent),
      );

      removedContent = newRemovedContent;
    }

    this.deleteRowRange(updateFromInd);

    Array.prototype.splice.apply(
      this.contents,
      [placePos, 0].concat(removedContent),
    );

    this.build(updateFromInd);
    this.selectRowRange(placePos, placePos + numRows - 1);
    this.lastClickedRowInd = placePos;
    this.refresh();

    if (this.onChangeHandler) {
      this.onChangeHandler();
    }
  };

  List.prototype.editSelectedRow = function () {
    if (this.selectedRows.length > 0) {
      var lastSelectedRowInd = this.selectedRows[this.selectedRows.length - 1];
      var lastSelectedRow = this.rows[lastSelectedRowInd];

      if (this.editHandler) {
        this.editHandler(lastSelectedRowInd);
      } else if (lastSelectedRow.editHandler) {
        lastSelectedRow.editHandler();
      }
    }
  };

  List.prototype.refresh = function () {
    if (this.rows.length === 0) {
      this.grRows.hide();
    } else if (!this.grRows.visible) {
      this.grRows.show();
    }

    this.element.layout.layout(true);
    this.updateScrollBar();
    this.resizeColumns();
    this.element.layout.resize();
    this.updateButtons();
  };

  List.prototype.deleteRow = function (row) {
    row = typeof row === "number" ? this.rows[row] : row;
    var rowIndex = row === "number" ? row : indexOf(this.rows, row);

    if (!row || rowIndex === -1) {
      return;
    }

    var indInSelectedRows = indexOf(this.selectedRows, rowIndex);

    if (row.element && isValid(row.element)) {
      this.element.grList.grRows.remove(row.element);
    }

    if (rowIndex !== -1) {
      this.rows.splice(rowIndex, 1);
      this.contents.splice(rowIndex, 1);
    }

    if (indInSelectedRows !== -1) {
      this.selectedRows.splice(indInSelectedRows, 1);
    }

    if (rowIndex === this.lastClickedRowInd) {
      this.lastClickedRowInd = 0;
    }

    if (this.onChangeHandler) {
      this.onChangeHandler();
    }
  };

  List.prototype.deleteSelectedRows = function () {
    this.selectedRows.sort(function (a, b) {
      return a - b;
    });

    var newSelectInd;
    if (this.selectedRows.length === 1) {
      newSelectInd = this.selectedRows[0];
    }

    for (var i = this.selectedRows.length - 1; i >= 0; i--) {
      this.deleteRow(this.selectedRows[i]);
    }

    if (this.rows.length > 0 && newSelectInd !== undefined) {
      if (newSelectInd > this.rows.length - 1) {
        newSelectInd = this.rows.length - 1;
      }

      this.selectRow(newSelectInd);
      this.lastClickedRowInd = newSelectInd;
    }
  };

  List.prototype.deleteRowRange = function (fromInd, toInd) {
    fromInd = fromInd === undefined ? 0 : fromInd;
    toInd = toInd === undefined ? this.rows.length - 1 : toInd;

    if (fromInd > toInd) {
      var tmp = fromInd;
      fromInd = toInd;
      toInd = tmp;
    }

    for (var i = toInd; i >= fromInd; i--) {
      this.deleteRow(i);
    }
  };

  List.prototype.getCursorPosFromEvent = function (event) {
    var result = positionRelativeToParent(this.element, event.target, [
      event.clientX,
      event.clientY,
    ]);

    return result;
  };

  List.prototype.getRowIndexUnderCursor = function (cursorPos) {
    var rowIndUnderCursor = binarySearch(
      this.rows,
      bind(function (row) {
        return (
          cursorPos[1] <
          positionRelativeToParent(this.element, row.element)[1] +
            row.element.size.height
        );
      }, this),
    );

    if (rowIndUnderCursor >= 0 && rowIndUnderCursor < this.rows.length) {
      /** make sure cursor is on the row */
      if (
        cursorPos[1] >
        positionRelativeToParent(
          this.element,
          this.rows[rowIndUnderCursor].element,
        )[1]
      ) {
        return rowIndUnderCursor;
      }
    }
  };

  List.prototype.onClick = function (event) {
    var cursorPos = this.getCursorPosFromEvent(event);
    var rowIndUnderCursor = this.getRowIndexUnderCursor(cursorPos);

    if (rowIndUnderCursor !== undefined) {
      var ctrlKey =
        (AE_OS === OS.WIN && event.ctrlKey) ||
        (AE_OS === OS.MAC && event.metaKey);

      var selectRange = undefined;
      if (event.shiftKey) {
        selectRange = {
          start: this.lastClickedRowInd || 0,
          end: rowIndUnderCursor,
        };
      } else {
        this.lastClickedRowInd = rowIndUnderCursor;
      }

      if (!ctrlKey) {
        this.deselectAllRows();
      }

      if (selectRange) {
        this.selectRowRange(selectRange.start, selectRange.end);
      } else if (ctrlKey) {
        this.inverseRowSelection(rowIndUnderCursor);
      } else {
        this.selectRow(rowIndUnderCursor);
      }

      this.rows[rowIndUnderCursor].onClick(event);
    } else {
      this.deselectAllRows();
    }
  };

  List.prototype.updateButtons = function () {
    if (this.selectedRows.length === 0) {
      this.parentGroup.grButtons.btnEdit.enabled = false;
      this.parentGroup.grButtons.btnDelete.enabled = false;
      this.parentGroup.grButtons.btnMoveUp.enabled = false;
      this.parentGroup.grButtons.btnMoveDown.enabled = false;
    } else {
      this.parentGroup.grButtons.btnEdit.enabled = true;
      this.parentGroup.grButtons.btnDelete.enabled = true;
      this.parentGroup.grButtons.btnMoveUp.enabled = true;
      this.parentGroup.grButtons.btnMoveDown.enabled = true;
    }
  };

  List.prototype.selectRow = function (rowIndex) {
    if (
      rowIndex >= 0 &&
      rowIndex < this.rows.length &&
      indexOf(this.selectedRows, rowIndex) === -1
    ) {
      var row = this.rows[rowIndex];
      row.setBgColor(row.getColorSelected());

      this.selectedRows.push(rowIndex);
      this.updateButtons();
    }
  };

  List.prototype.selectRowRange = function (fromInd, toInd) {
    fromInd = fromInd === undefined ? 0 : fromInd;
    toInd = toInd === undefined ? this.rows.length - 1 : toInd;

    var iDiff = fromInd < toInd ? 1 : -1;

    for (var i = fromInd; iDiff > 0 ? i <= toInd : i >= toInd; i += iDiff) {
      this.selectRow(i);
    }
  };

  List.prototype.deselectRow = function (rowIndex) {
    var ind = indexOf(this.selectedRows, rowIndex);
    if (ind !== -1) {
      var row = this.rows[rowIndex];
      row.setBgColor(row.getColorDeselected());

      this.selectedRows.splice(ind, 1);
      this.updateButtons();
    }
  };

  List.prototype.deselectAllRows = function () {
    for (var i = 0; i < this.selectedRows.length; i++) {
      var row = this.rows[this.selectedRows[i]];
      row.setBgColor(row.getColorDeselected());
    }

    this.selectedRows.length = 0;
    this.updateButtons();
  };

  List.prototype.inverseRowSelection = function (rowIndex) {
    if (indexOf(this.selectedRows, rowIndex) === -1) {
      this.selectRow(rowIndex);
    } else {
      this.deselectRow(rowIndex);
    }
  };

  List.prototype.updateScrollBar = function () {
    if (!this.element.grList.grRows.size) {
      this.element.layout.layout(true);
    }

    var scrollBar = this.element.scrollBar;
    var grSlider = this.element.grList.grSlider;
    var sizeDiff =
      this.element.grList.grRows.size.height - this.element.grList.size.height;

    var moveSliderGroup = function (event) {
      if (this.grSlider) {
        this.grSlider.location.x = event.clientX;
        this.grSlider.location.y = event.clientY;
      }
    };

    if (sizeDiff > 0) {
      if (!scrollBar) {
        scrollBar = this.element.add(
          "Scrollbar { \
          alignment: ['right', 'fill'], \
        }",
        );

        scrollBar.maximumSize.width = 12;
        scrollBar.onChange = bind(function () {
          this.element.grList.grRows.location.y = -this.element.scrollBar.value;
        }, this);
        scrollBar.onChanging = scrollBar.onChange;

        this.element.scrollBar = scrollBar;

        if (!grSlider) {
          /** slider to scroll the list using mouse wheel */
          grSlider = this.element.grList.add(
            "Group {\
            alignment: 'top', \
            maximumSize: [1, 1], \
            slider: Slider { \
              minvalue: -1, \
              maxvalue: 1, \
            }, \
          }",
          );

          /** remove all appearance on the slider */
          grSlider.slider.onDraw = function () {};

          grSlider.slider.onChanging = function () {
            scrollBar.value += this.value * 10;
            scrollBar.notify();

            this.value = 0;
          };

          /** remove mousedown event */
          grSlider.slider.addEventListener("mousedown", function (event) {
            if (event.cancelable) {
              event.preventDefault();
            }
          });

          this.element.grList.grSlider = grSlider;
          this.element.grList.addEventListener("mousemove", moveSliderGroup);
        }
      }

      this.element.layout.layout(true);
      this.element.layout.resize();

      scrollBar.minvalue = 0;
      scrollBar.maxvalue = sizeDiff;
      scrollBar.notify();
    } else if (scrollBar) {
      this.element.remove(scrollBar);
      this.element.scrollBar = undefined;
      this.element.grList.removeEventListener("mousemove", moveSliderGroup);

      if (grSlider) {
        this.element.grList.remove(grSlider);
        this.element.grList.grSlider = undefined;
      }

      this.element.layout.layout(true);
      // this.element.layout.resize();
    }
  };

  List.prototype.scrollToBottom = function () {
    var scrollBar = this.element.scrollBar;

    if (scrollBar) {
      scrollBar.value = scrollBar.maxvalue;
      scrollBar.notify();
    }
  };

  function ValuesRow(parentEl) {
    Row.call(this, parentEl);
    this.columnMargins = [5, 2, 0, 1];
    this.filled = false;
  }

  ValuesRow.prototype = create(Row.prototype);

  ValuesRow.prototype.fillHandler = function (value) {
    if (value !== undefined) {
      var valueColumn = this.add("StaticText { text: '" + value + "%' }");
      valueColumn.margins = this.columnMargins;
      this.filled = true;
    } else {
      if (!this.element.parent.size) {
        this.element.window.layout.layout(true);
      }

      if (this.element.parent.size) {
        var strSize = this.element.graphics.measureString("1");

        this.setMinSize([
          this.element.parent.size[0],
          strSize[1] + this.columnMargins[1] + this.columnMargins[3],
        ]);
      }
    }
  };

  ValuesRow.prototype.editHandler = function () {
    this.editing = true;

    var valueEl = this.columns.length > 0 ? this.columns[0].element : undefined;
    var value = valueEl ? strToNumStr(valueEl.text) : "";

    this.floatText = new FloatEditText(this.element, value);

    this.floatText.setSize(this.element.size);
    this.floatText.setLocation([0, 0]);

    this.floatText.setOnBlurFn(
      bind(function () {
        if (!this.filled && this.list) {
          this.list.deleteRow(this);
          this.list.refresh();
        }

        this.floatText.removeSelf();
        this.editing = false;
      }, this),
    );

    this.floatText.setOnChangeFn(
      bind(function (text) {
        var inputValue = strToNumStr(text);

        if (inputValue) {
          // remove floatText to free up space for new text element
          this.floatText.removeSelf();

          this.edit(inputValue);
        }
      }, this),
    );
  };

  ValuesRow.prototype.abortEditHandler = function () {
    if (this.floatText && this.floatText.onBlurFn) {
      this.floatText.onBlurFn();
    }
  };

  ValuesRow.prototype.onDoubleClickHandler = function () {
    this.editHandler();
  };

  function ValuesList(parentEl) {
    List.call(this, parentEl);

    this.RowClass = ValuesRow;

    var listValues =
      typeof preferences.presetValues === "string"
        ? JSON.parse(preferences.presetValues)
        : preferences.presetValues;

    if (listValues) {
      this.contents = listValues;
    }

    this.build();
    this.setMaxSize([9999, 125]);
    this.setMinSize([0, 125]);
  }

  ValuesList.prototype = create(List.prototype);

  ValuesList.prototype.onChangeHandler = function () {
    preferences.save("presetValues", JSON.stringify(this.contents));
  };

  function GeneralSettings(parentEl, zoom) {
    this.zoom = zoom;

    this.element = parentEl.add(
      "tab { \
      text: 'General', \
      alignChildren: ['fill', 'top'], \
      orientation: 'row', \
      margins: [12, 10, 0, 10], \
      gr: Group { \
        orientation: 'column', \
        alignChildren: ['fill', 'top'], \
        pnlSync: Panel { \
          alignChildren: 'left', \
          grCheck: Group {}, \
          txtDescription: StaticText { \
            text: 'Synchronize zoom value in the script with the actual value in the active viewport when hovering over the panel with mouse cursor.', \
            characters: 55, \
            properties: { multiline: true }, \
          },\
        }, \
        pnlHighDPI: Panel { \
          alignChildren: 'left', \
          grCheck: Group {}, \
          grScale: Group { \
            spacing: 0, \
            txt: StaticText { text: 'Scale Factor: ' }, \
          }, \
          txtDescription: StaticText { \
            text: 'Enabling this option fixes the problem where the actual zoom change is more than what is set in the UI panel on high DPI displays.', \
            characters: 55, \
            properties: { multiline: true }, \
          },\
        }, \
        pnlSlider: Panel { \
          text: 'Slider', \
          alignChildren: 'left', \
          grCheck: Group {}, \
          grMinMax: Group { \
            orientation: 'column', \
            spacing: 2, \
            grMinValue: Group { \
              spacing: 0, \
              txt: StaticText { text: 'Slider Min: ' }, \
            }, \
            grMaxValue: Group { \
              spacing: 0, \
              txt: StaticText { text: 'Slider Max: ' }, \
            }, \
          }, \
        }, \
        pnlPresetList: Panel { \
          text: 'Preset Values', \
          alignChildren: ['fill', 'top'], \
        }, \
      }, \
    }",
    );

    this.settingsOnStart = {
      syncWithView: preferences.syncWithView,
      highDPI: preferences.highDPI,
      showSlider: preferences.showSlider,
      sliderMin: preferences.sliderMin,
      sliderMax: preferences.sliderMax,
      presetValues: preferences.presetValues,
    };

    var pnlSync = this.element.gr.pnlSync;
    var pnlHighDPI = this.element.gr.pnlHighDPI;
    var pnlSlider = this.element.gr.pnlSlider;
    var grMinMax = pnlSlider.grMinMax;

    function saveHighDpiPrefs() {
      preferences.save("highDPI", {
        enabled: pnlHighDPI.grCheck.element.check.value,
        scale: pnlHighDPI.grScale.numValue.getValue(),
      });
    }

    pnlSync.grCheck = new Checkbox(
      pnlSync,
      "Sync zoom value with viewport",
      pnlSync.grCheck,
    );

    pnlSync.grCheck.setValue(preferences.syncWithView);
    pnlSync.grCheck.setOnClick(function () {
      preferences.save("syncWithView", this.value);
    });

    pnlHighDPI.grCheck = new Checkbox(
      pnlHighDPI,
      "High DPI display (Retina) support",
      pnlHighDPI.grCheck,
    );

    pnlHighDPI.grCheck.setValue(preferences.highDPI.enabled);
    pnlHighDPI.grCheck.setOnClick(function () {
      pnlHighDPI.grScale.enabled = this.value;
      saveHighDpiPrefs();
    });

    pnlHighDPI.grScale.numValue = new NumberValue(
      pnlHighDPI.grScale,
      "x",
      preferences.highDPI.scale,
      1,
      undefined,
      undefined,
      undefined,
      saveHighDpiPrefs,
      "Difference between UI and actual values",
    );
    pnlHighDPI.grScale.enabled = preferences.highDPI.enabled;

    pnlSlider.grCheck = new Checkbox(pnlSlider, "Show Slider", pnlSlider.grCheck);
    pnlSlider.grCheck.setValue(preferences.showSlider);
    pnlSlider.grCheck.setOnClick(function () {
      zoom.showHideSlider(this.value);
    });

    grMinMax.grMinValue.numValue = new NumberValue(
      grMinMax.grMinValue,
      "%",
      preferences.sliderMin,
      1,
      preferences.sliderMax,
    );

    grMinMax.grMaxValue.numValue = new NumberValue(
      grMinMax.grMaxValue,
      "%",
      preferences.sliderMax,
      preferences.sliderMin,
    );

    grMinMax.grMinValue.numValue.onChangeFn = bind(function (val) {
      preferences.save("sliderMin", val);
      grMinMax.grMaxValue.numValue.minValue = val;

      if (zoom.zoomSlider && isValid(zoom.zoomSlider.element)) {
        zoom.zoomSlider.setMin(val);
      }
    }, this);

    grMinMax.grMaxValue.numValue.onChangeFn = bind(function (val) {
      preferences.save("sliderMax", val);
      grMinMax.grMinValue.numValue.maxValue = val;

      if (zoom.zoomSlider && isValid(zoom.zoomSlider.element)) {
        zoom.zoomSlider.setMax(val);
      }
    }, this);

    var maxTextSize = pnlSlider.graphics.measureString(
      grMinMax.grMaxValue.txt.text,
    );
    grMinMax.grMinValue.txt.preferredSize = maxTextSize;
    grMinMax.grMaxValue.txt.preferredSize = maxTextSize;

    this.element.gr.pnlPresetList.list = new ValuesList(
      this.element.gr.pnlPresetList,
    );
  }

  GeneralSettings.prototype.cancel = function () {
    var pnlSlider = this.element.gr.pnlSlider;

    preferences.save("syncWithView", this.settingsOnStart.syncWithView);
    preferences.save("highDPI", this.settingsOnStart.highDPI);
    this.zoom.showHideSlider(this.settingsOnStart.showSlider);
    pnlSlider.grMinMax.grMinValue.numValue.onChangeFn(
      this.settingsOnStart.sliderMin,
    );
    pnlSlider.grMinMax.grMaxValue.numValue.onChangeFn(
      this.settingsOnStart.sliderMax,
    );
    preferences.save("presetValues", this.settingsOnStart.presetValues);
  };

  function KeyCombination(parentEl, keyNames, minWidth, alignChildren) {
    /**
     a lock for sort of thread safety
     when someone presses keys too fast multiple updateKeys()
     may run simultaneously
     */
    this.updating = false;

    /** keys in the plugin format, may not be present */
    this.keyCodes = undefined;

    this.keyNames = keyNames;
    this.alignChildren = alignChildren || "left";

    this.element = parentEl.add(
      "Group { \
      alignChildren: ['fill', 'fill'], \
    }",
    );

    var g = this.element.graphics;
    this.b = g.newBrush(g.BrushType.SOLID_COLOR, [0.11, 0.11, 0.11, 1]);
    this.p = g.newPen(g.PenType.SOLID_COLOR, [0.75, 0.75, 0.75, 1], 1);

    if (minWidth) {
      this.element.minimumSize = [minWidth, 0];
    }

    this.addCombination(keyNames);
  }

  KeyCombination.prototype.addCombination = function (keyNames) {
    this.keyNames = keyNames;

    var gr = this.element.add(
      "Group { \
      spacing: 3, \
      alignChildren: ['" +
        this.alignChildren +
        "', 'center'], \
    }",
    );

    for (var i = 0; i < keyNames.length; i++) {
      if (!isValid(gr)) {
        break;
      }

      if (i > 0) {
        gr.add("StaticText { text: '+' }");
      }

      var pnlKey = gr.add(
        "Panel { \
        margins: [2, 1, 2, 1], \
        txt: StaticText {}, \
      }",
      );

      pnlKey.txt.text = keyNames[i];

      if (isValid(pnlKey)) {
        pnlKey.graphics.backgroundColor = this.b;
        pnlKey.txt.graphics.foregroundColor = this.p;
      }
    }
  };

  KeyCombination.prototype.updateKeysWithCodes = function (keyCodes) {
    var keyNames = keysFromKeyCodes(keyCodes);

    this.keyCodes = keyCodes;
    this.updateKeys(keyNames);
  };

  KeyCombination.prototype.updateKeys = function (keyNames) {
    try {
      if (!this.updating) {
        this.updating = true;
        var children = this.element.children;

        for (var i = children.length - 1; i >= 0; i--) {
          if (isValid(this.element.children[i])) {
            this.element.remove(i);
          }
        }

        this.addCombination(keyNames);

        // this.element.layout.layout(true);
        this.updating = false;
      }
    } catch (error) {
      alert("Error at line " + error.line + ":\n" + error.message);
    }
  };

  function KeyBindingsRow(list) {
    Row.call(this, list);

    this.colorSelectedDisabled = [0.2, 0.2, 0.2, 1];
    this.element.spacing = 2;
    this.columnMargins = [
      [5, 2, 5, 2],
      [5, 2, 5, 2],
      [5, 2, 5, 2],
      [5, 2, 5, 2],
    ];
    this.columnAlignments = [
      ["left", "fill"],
      ["fill", "fill"],
      ["right", "fill"],
      ["right", "center"],
    ];

    this.filled = false;
  }

  KeyBindingsRow.prototype = create(Row.prototype);

  KeyBindingsRow.prototype.alignColumns = function () {
    for (var i = 0; i < this.columns.length; i++) {
      this.columns[i].alignment = this.columnAlignments[i];
      this.columns[i].margins = this.columnMargins[i];
    }
  };

  KeyBindingsRow.prototype.fillHandler = function (values) {
    if (values !== undefined) {
      this.clmnCheck = this.add("Checkbox { alignment: ['center', 'fill'] }");
      this.clmnCheck.element.value = values.enabled;
      this.clmnCheck.element.maximumSize = [9999, 15];

      /** save key bindings when Check is clicked */
      this.clmnCheck.element.onClick = bind(function () {
        values.enabled = this.clmnCheck.element.value;
        this.checkClick(this.clmnCheck.element.value);
        this.list.onChangeHandler();
      }, this);

      this.clmnKeys = this.add(function (columnGr) {
        var keyCombination = new KeyCombination(columnGr, []);
        keyCombination.updateKeysWithCodes(values.keyCodes);
        return keyCombination;
      });

      this.clmnAction = this.add("StaticText {}");
      this.clmnAction.element.text = KB_ACTION_NAMES[values.action];

      this.clmnAmount = this.add("StaticText {}");
      this.clmnAmount.element.text =
        (values.action === KB_ACTION.DECREMENT ? -values.amount : values.amount) +
        "%";

      this.alignColumns();
      this.checkClick(values.enabled);

      this.filled = true;
    }
  };

  KeyBindingsRow.prototype.onClickHandler = function (event) {
    var check = this.clmnCheck.element;
    var cursorPos = positionRelativeToParent(
      this.list.element.grList,
      event.target,
      [event.clientX, event.clientY],
    );
    var checkPos = positionRelativeToParent(this.list.element.grList, check);

    if (
      cursorPos[0] >= checkPos[0] &&
      cursorPos[0] <= checkPos[0] + check.size[0] &&
      cursorPos[1] >= checkPos[1] &&
      cursorPos[1] <= checkPos[1] + check.size[1]
    ) {
      this.clmnCheck.element.notify();
      return false; // tell the row to not call its double click handler
    }
  };

  KeyBindingsRow.prototype.onDoubleClickHandler = function () {
    var rowInd = indexOf(this.list.rows, this);

    if (rowInd !== -1) {
      this.list.editHandler(rowInd);
    }
  };

  KeyBindingsRow.prototype.checkClick = function (value) {
    for (var i = 1; i < this.columns.length; i++) {
      this.columns[i].enabled = value;
    }

    /** if this row is selected then set the right bg color */
    for (i = 0; i < this.list.selectedRows.length; i++) {
      if (this.list.rows[this.list.selectedRows[i]] === this) {
        this.setBgColor(this.getColorSelected());
        break;
      }
    }
  };

  KeyBindingsRow.prototype.enable = function () {
    for (var i = 1; i < this.columns.length; i++) {
      this.columns[i].enabled = true;
    }
  };

  KeyBindingsRow.prototype.disable = function () {
    for (var i = 1; i < this.columns.length; i++) {
      this.columns[i].enabled = false;
    }
  };

  KeyBindingsRow.prototype.getColorSelected = function () {
    if (this.clmnCheck) {
      if (this.clmnCheck.element.value) {
        return this.colorSelected;
      } else {
        return this.colorSelectedDisabled;
      }
    }
  };

  function KeyBindingsColumnNamesRow(parentEl) {
    KeyBindingsRow.call(this, parentEl);
    this.names = ["Enable", "Key Combination", "Action", "Amount"];
    this.element.margins = [0, 0, 0, 1];
    this.columnMargins = [
      [5, 0, 5, 0],
      [5, 0, 5, 0],
      [5, 0, 5, 0],
      [5, 0, 5, 0],
    ];
    this.setBgColor([0.113, 0.113, 0.113, 1]);
  }

  KeyBindingsColumnNamesRow.prototype = create(Row.prototype);

  KeyBindingsColumnNamesRow.prototype.fillHandler = function () {
    for (var i = 0; i < this.names.length; i++) {
      var col = this.add("StaticText { text: '" + this.names[i] + "' }");

      if (this.columnMargins[i]) {
        col.margins = this.columnMargins[i];
      }

      if (this.columnAlignments[i]) {
        col.alignment = this.columnAlignments[i];
      }
    }

    this.setColumnsBgColor([0.149, 0.149, 0.149, 1]);
  };

  function KeyBindingsEditRow(list) {
    KeyBindingsRow.call(this, list);

    this.isMouseOverSaveBtn = false;
    this.isKeyCapturing = false;
    this.columnMargins = [
      [5, 2, 5, 2],
      [0, 0, 0, 0],
      [5, 2, 5, 2],
      [5, 2, 5, 2],
    ];
  }

  KeyBindingsEditRow.prototype = create(KeyBindingsRow.prototype);

  /** Support for deprecated actions */
  KeyBindingsEditRow.actionToSelection = {};
  KeyBindingsEditRow.actionToSelection[KB_ACTION.CHANGE] = 0;
  KeyBindingsEditRow.actionToSelection[KB_ACTION.DECREMENT] = 0; // deprecated
  KeyBindingsEditRow.actionToSelection[KB_ACTION.SET_TO] = 1;
  KeyBindingsEditRow.selectionToAction = [KB_ACTION.CHANGE, KB_ACTION.SET_TO];

  KeyBindingsEditRow.prototype.getValues = function () {
    return {
      enabled: this.clmnCheck.element.value,
      keyCodes: this.keyCodes,
      action:
        KeyBindingsEditRow.selectionToAction[
          this.clmnAction.element.selection.index
        ],
      amount: this.clmnAmount.element.getValue(),
    };
  };

  KeyBindingsEditRow.prototype.fillHandler = function (values) {
    values = values || {
      enabled: true,
      keyCodes: undefined,
      action: KB_ACTION.CHANGE,
      amount: 1,
    };

    this.keyCodes = values.keyCodes;

    this.clmnCheck = this.add("Checkbox { alignment: ['center', 'fill'] }");
    this.clmnCheck.element.value = values.enabled;
    this.clmnCheck.element.maximumSize = [9999, 15];

    this.clmnKeys = this.add(
      bind(function (columnGr) {
        var grKeys = columnGr.add(
          "Group { \
          orientation: 'stack', \
          alignChildren: 'fill', \
          grStroke: Custom { \
            visible: false, \
          }, \
        }",
        );

        this.keyCombination = new KeyCombination(grKeys, []);

        if (values.keyCodes) {
          this.keyCombination.updateKeysWithCodes(values.keyCodes);
        }

        this.keyCombination.element.margins = [5, 2, 5, 2];
        this.keyCombination.element.graphics.backgroundColor =
          grKeys.graphics.newBrush(
            grKeys.graphics.BrushType.SOLID_COLOR,
            [0, 0, 0, 0],
          );

        grKeys.addEventListener("mousemove", function (event) {
          if (event.eventPhase === "target") {
            this.grStroke.visible = true;
          }
        });
        grKeys.addEventListener(
          "mouseout",
          bind(function (event) {
            if (!this.isKeyCapturing && event.eventPhase === "target") {
              this.clmnKeys.element.grStroke.visible = false;
            }
          }, this),
        );

        grKeys.grStroke.onDraw = bind(function () {
          var penColor = this.isKeyCapturing ? BLUE_COLOR : [0.3, 0.3, 0.3, 1];

          var brushColor = this.isKeyCapturing
            ? [0, 0, 0, 1]
            : [0.16, 0.16, 0.16, 1];

          var grStroke = this.clmnKeys.element.grStroke;
          var g = grStroke.graphics;
          var p = g.newPen(g.PenType.SOLID_COLOR, penColor, 2);
          var b = g.newBrush(g.BrushType.SOLID_COLOR, brushColor);

          drawRoundRect(0, g, b, p, grStroke.size);
        }, this);

        grKeys.btn = grKeys.add("Button { helpTip: 'Click to change' }");
        grKeys.btn.onDraw = function () {};
        grKeys.btn.addEventListener(
          "mousedown",
          bind(function () {
            this.startKeyCapture();
          }, this),
        );

        /** Put a link to this object in global scope so we can access it from the plug-in */
        $.global.__zoom_key_capture_object__ = this;

        return grKeys;
      }, this),
    );

    this.clmnAction = this.add(function (columnGr) {
      return columnGr.add("dropdownlist", undefined, [
        KB_ACTION_NAMES[KB_ACTION.CHANGE],
        KB_ACTION_NAMES[KB_ACTION.SET_TO],
      ]);
    });
    this.clmnAction.element.selection =
      KeyBindingsEditRow.actionToSelection[values.action];
    this.clmnAction.element.onChange = bind(function () {
      if (this.clmnAction.element.selection.index === 0) {
        this.clmnAmount.element.minValue = undefined;
      } else if (this.clmnAction.element.selection.index === 1) {
        this.clmnAmount.element.minValue = 1;

        if (this.clmnAmount.element.getValue() < 0) {
          this.clmnAmount.element.setValue(0);
        }
      }
    }, this);

    this.clmnAmount = this.add(function (columnGr) {
      return new NumberValue(
        columnGr,
        "%",
        values.action === KB_ACTION.DECREMENT ? -values.amount : values.amount,
        values.action === KB_ACTION.SET_TO ? 1 : undefined,
      );
    });

    this.alignColumns();
  };

  KeyBindingsEditRow.prototype.startKeyCapture = function () {
    if (zoomPlugin.isAvailable()) {
      this.isKeyCapturing = true;
      this.clmnKeys.element.btn.active = false;
      this.clmnKeys.element.btn.visible = false;
      this.clmnKeys.element.grStroke.visible = true;
      this.clmnKeys.element.grStroke.notify("onDraw");

      /** disable all other columns */
      for (var i = 0; i < this.columns.length; i++) {
        if (this.columns[i] === this.clmnKeys) {
          continue;
        }

        this.columns[i].enabled = false;
      }

      this.keyCombination.updateKeys([]);
      this.list.editWindow.addCaptureInfo();

      try {
        zoomPlugin.startKeyCapture();
      } catch (error) {
        alert("Error at line " + $.line + ":\n" + error.message);
      }
    }
  };

  KeyBindingsEditRow.prototype.endKeyCapture = function () {
    this.list.editWindow.deleteCaptureInfo();
    this.isKeyCapturing = false;
    this.clmnKeys.element.grStroke.notify("onDraw");
    this.clmnKeys.element.grStroke.visible = false;
    this.clmnKeys.element.btn.visible = true;

    /** enable all columns */
    for (var i = 0; i < this.columns.length; i++) {
      this.columns[i].enabled = true;
    }

    if (zoomPlugin.isAvailable()) {
      try {
        zoomPlugin.endKeyCapture();
      } catch (error) {
        alert("Error at line " + error.line + ":\n" + error.message);
      }
    }
  };

  /**
   * This function is called from the zoom plugin.
   * It receives currently pressed keyboard and mouse keys in the plugin format
   * and translates them into readable format.
   * @param { number } type type of the event: KEY_PRESSED, MOUSE_PRESSED, SCROLL_WHEEL
   * @param { number } mask the modifier keys that were pressed at the time of the event: Ctrl, Win/Cmd, Shift, Alt/Option
   * @param { number } key the key code of the button that was pressed: keyboard or mouse button or mouse wheel direction
   */
  KeyBindingsEditRow.prototype.passFn = function (type, mask, keycode) {
    if (
      type === EVENT_KEY_PRESSED &&
      (keycode === VC_ENTER || keycode === VC_EX_ENTER)
    ) {
      if (this.keyCombination.keyNames.length > 0) {
        this.keyCodes = this.keyCombination.keyCodes;
        this.endKeyCapture();
      } else if (this.keyCodes) {
        this.keyCombination.updateKeysWithCodes(this.keyCodes);
        this.endKeyCapture();
      } else {
        this.element.window.close();
      }
    } else if (keycode === VC_ESCAPE) {
      if (type === EVENT_KEY_RELEASED) {
        if (!this.keyCodes) {
          this.element.window.close();
        } else {
          this.keyCombination.updateKeysWithCodes(this.keyCodes);
          this.endKeyCapture();
        }
      }
    } else if (!(type === EVENT_MOUSE_PRESSED && this.isMouseOverSaveBtn)) {
      this.keyCombination.updateKeysWithCodes({
        type: type,
        mask: mask,
        keycode: keycode,
      });

      this.element.layout.layout(true);
    }
  };

  function KeyBindingEditWindow(values, row, title) {
    if (!zoomPlugin.isAvailable()) {
      alert(
        "Zoom plug-in is not found.\nPlease install Zoom plug-in to use key bindings.",
      );
      return;
    }

    this.element = new Window(
      "palette { \
      properties: { \
        resizeable: false, \
      }, \
      minimumSize: [500, 0], \
      alignChildren: 'fill', \
    }",
      title || "Edit Key Binding",
    );

    var editList = new BasicList(this.element);
    editList.editWindow = this;
    editList.RowClass = KeyBindingsEditRow;
    editList.ColumnNamesClass = KeyBindingsColumnNamesRow;
    editList.addColumnNames();
    editList.contents.push(values);
    editList.build();
    editList.refresh();

    this.element.grCaptureInfo = this.element.add(
      "Group { \
      orientation: 'stack', \
      alignChildren: 'fill', \
      alignment: ['fill', 'bottom'], \
    }",
    );

    this.element.grButtons = this.element.add(
      "Group { \
      alignment: ['fill', 'bottom'], \
      alignChildren: ['right', 'center'], \
      btnSave: IconButton { title: 'OK', preferredSize: [100, 22] }, \
      btnCancel: IconButton { title: 'Cancel', preferredSize: [100, 22] }, \
    }",
    );

    this.element.grButtons.btnSave.addEventListener("mouseover", function () {
      editList.rows[0].isMouseOverSaveBtn = true;
    });

    this.element.grButtons.btnSave.addEventListener("mouseout", function () {
      editList.rows[0].isMouseOverSaveBtn = false;
    });

    this.element.grButtons.btnSave.onClick = bind(function () {
      /** if key capturing, save the currently pressed keys */
      if (editList.rows[0].isKeyCapturing) {
        editList.rows[0].passFn(EVENT_KEY_PRESSED, undefined, VC_ENTER);
      }

      if (isValid(this.element)) {
        var newValues = editList.rows[0].getValues();
        this.element.close();

        row.edit(newValues);
        row.checkClick(newValues.enabled);
        row.list.refresh();
      }
    }, this);

    this.element.grButtons.btnCancel.onClick = bind(function () {
      this.element.close();
    }, this);

    /** End key capture if the window is closed */
    this.element.onClose = function () {
      /** If new key bind doesn't have any key codes delete it */
      if (!editList.rows[0].keyCodes) {
        row.list.deleteRow(row);
      }

      row.list.editing = false;
      editList.rows[0].endKeyCapture();
    };

    /** If this is new key bind */
    if (!values) {
      editList.rows[0].startKeyCapture();
    }

    this.element.layout.layout(true);
    this.element.show();
  }

  KeyBindingEditWindow.prototype.addCaptureInfo = function () {
    var grCaptureInfo = this.element.grCaptureInfo;

    var grStroke = grCaptureInfo.add(
      "Group { \
      alignChildren: ['fill', 'fill'], \
      strokeEl: Custom {}, \
    }",
    );
    grStroke.onDraw = function () {
      var g = this.graphics;
      var b = g.newBrush(g.BrushType.SOLID_COLOR, [0, 0, 0, 1]);
      var p = g.newPen(g.PenType.SOLID_COLOR, BLUE_COLOR, 2);
      drawRoundRect(0, g, b, p, this.size);
    };

    grCaptureInfo.grText = grCaptureInfo.add(
      "Group { \
      orientation: 'column', \
      margins: 10, \
      txtTop: StaticText { \
        text: 'Press desired key combination. You can use keyboard and mouse.', \
      }, \
      grBottomText: Group { \
        spacing: 4, \
        txt0: StaticText { text: 'Press' }, \
        grEnter: Group {}, \
        txt1: StaticText { text: 'to accept.' }, \
        grEscape: Group {}, \
        txt2: StaticText { text: 'to cancel.' }, \
      }, \
    }",
    );

    grCaptureInfo.grText.grBottomText.grEnter.keyCombination = new KeyCombination(
      grCaptureInfo.grText.grBottomText.grEnter,
      ["Enter"],
    );
    grCaptureInfo.grText.grBottomText.grEscape.keyCombination =
      new KeyCombination(grCaptureInfo.grText.grBottomText.grEscape, ["Escape"]);

    this.element.layout.layout(true);
  };

  KeyBindingEditWindow.prototype.deleteCaptureInfo = function () {
    var grCaptureInfo = this.element.grCaptureInfo;
    for (var i = grCaptureInfo.children.length - 1; i >= 0; i--) {
      grCaptureInfo.remove(i);
    }

    this.element.layout.layout(true);
    this.element.size[1] -= grCaptureInfo.size[1];
    grCaptureInfo.size[1] = 0;
    this.element.layout.resize();
  };

  function KeyBindingsList(parentEl) {
    List.call(this, parentEl);

    this.RowClass = KeyBindingsRow;
    this.ColumnNamesClass = KeyBindingsColumnNamesRow;

    var listValues =
      typeof preferences.keyBindings === "string"
        ? JSON.parse(preferences.keyBindings)
        : preferences.keyBindings;

    if (listValues) {
      this.contents = listValues;
    }

    this.addColumnNames();
    this.build();
    this.setMaxSize([9999, 300]);
    this.setMinSize([0, 300]);
    this.refresh();
  }

  KeyBindingsList.prototype = create(List.prototype);

  KeyBindingsList.prototype.editHandler = function (rowInd) {
    this.editing = true;
    var row = this.rows[rowInd];
    var values = this.contents[rowInd];

    this.editWindow = new KeyBindingEditWindow(
      values,
      row,
      values ? "Edit Key Binding" : "Create Key Binding",
    );
    windows.new(this.editWindow);
  };

  KeyBindingsList.prototype.abortEditHandler = function () {
    this.editing = false;
    if (this.editWindow) {
      this.editWindow.element.close();
    }
  };

  KeyBindingsList.prototype.onChangeHandler = function () {
    preferences.save("keyBindings", JSON.stringify(this.contents));
  };

  function KeyBindingsSettings(parentEl) {
    this.keyBindingsArr = [];
    this.linesArr = [];
    this.drawn = false;

    this.element = parentEl.add(
      "tab { \
      text: 'Key Bindings', \
      alignChildren: ['left', 'top'], \
      orientation: 'row', \
      margins: [12, 10, 0, 10], \
    }",
    );

    this.settingsOnStart = preferences.keyBindings;
  }

  KeyBindingsSettings.prototype.draw = function () {
    if (!this.drawn) {
      this.element.gr = this.element.add(
        "Group { \
        alignment: ['fill', 'fill'], \
        alignChildren: ['fill', 'top'], \
        orientation: 'column', \
      }",
      );

      this.element.maximumSize.width = 600;

      /** Show plug-in status if plug-in is not found */
      if (zoomPlugin.status() !== ZOOM_PLUGIN_STATUS.INITIALIZED) {
        this.addStatus();
      }

      this.element.gr.keyBindingsList = new KeyBindingsList(this.element.gr);

      if (zoomPlugin.status() !== ZOOM_PLUGIN_STATUS.INITIALIZED) {
        this.element.gr.keyBindingsList.parentGroup.enabled = false;
      }

      this.element.layout.layout(true);
      this.element.layout.resize();
      this.drawn = true;
    }
  };

  KeyBindingsSettings.prototype.addStatus = function () {
    this.element.gr.grPluginStatus = this.element.gr.add(
      "Group { \
      alignChildren: ['fill', 'top'], \
    }",
    );

    var grPluginStatus = this.element.gr.grPluginStatus;
    grPluginStatus.pluginStatusPanel = new PluginStatusWithButton(grPluginStatus);

    var grText = grPluginStatus.pluginStatusPanel.element.grStatus.gr.grText;
    var statusText = grText.children[0].text;

    grText.children[0].text = "Key Bindings are not available:";
    grText.add("StaticText { text: '" + statusText + "' }");
  };

  KeyBindingsSettings.prototype.deleteStatus = function () {
    if (this.element.gr.grPluginStatus) {
      this.element.gr.remove(this.element.gr.grPluginStatus);
      this.element.gr.grPluginStatus = undefined;
    }
  };

  KeyBindingsSettings.prototype.reloadStatus = function () {
    if (this.element.gr.grPluginStatus) {
      var pluginStatusPanel = this.element.gr.grPluginStatus.pluginStatusPanel;

      if (pluginStatusPanel) {
        var statusChanged = pluginStatusPanel.setPluginStatus();

        if (statusChanged) {
          if (pluginStatusPanel.pluginStatus === ZOOM_PLUGIN_STATUS.INITIALIZED) {
            this.deleteStatus();
            this.element.gr.keyBindingsList.parentGroup.enabled = true;
          }

          this.element.layout.layout(true);
          this.element.layout.resize();
        }
      }
    }
  };

  /** Save the key bindings to the AE's preferences file */
  KeyBindingsSettings.prototype.saveAll = function () {
    if (this.drawn) {
      var bindingsArr = [];

      for (var i = 0; i < this.keyBindingsArr.length; i++) {
        var bEl = this.keyBindingsArr[i].element;

        bindingsArr.push({
          enabled: bEl.chkEnable.value,
          keyCodes: bEl.gr.grKeys.keyCombination.keyCodes,
          action: bEl.gr.ddlistAction.selection.index,
          amount: bEl.gr.grAmount.numberValue.getValue(),
        });
      }

      preferences.save("keyBindings", JSON.stringify(bindingsArr));
    }
  };

  KeyBindingsSettings.prototype.cancel = function () {
    if (this.drawn && this.settingsOnStart !== preferences.keyBindings) {
      preferences.save("keyBindings", this.settingsOnStart);
    }
  };

  function Line(parentEl) {
    this.element = parentEl.add(
      "Group {\
      orientation: '" +
        parentEl.orientation +
        "', \
      alignment: 'fill', \
      alignChildren: 'fill', \
      cLine: Custom {}, \
    }",
    );

    if (this.element.parent.orientation === "column") {
      this.element.cLine.preferredSize = [-1, 1];
    } else {
      this.element.cLine.preferredSize = [1, -1];
    }

    this.element.cLine.onDraw = function () {
      if (!parentEl.size) {
        parentEl.layout.layout(true);
      }

      var g = this.graphics;
      var c = [0.3, 0.3, 0.3, 1];
      var p = g.newPen(g.PenType.SOLID_COLOR, c, 1);

      if (this.parent.orientation === "column") {
        g.moveTo(0, 0);
        g.lineTo(this.size[0], 0);
        g.strokePath(p);
      } else {
        g.moveTo(0, 0);
        g.lineTo(0, this.size[1]);
        g.strokePath(p);
      }
    };
  }

  Line.prototype.forceOnDraw = function () {
    this.element.cLine.notify("onDraw");
  };

  function FoldingInfo(parentEl, unfoldEl, title) {
    this.unfoldEl = unfoldEl;

    this.element = parentEl.add(
      "Panel { \
      alignChildren: 'fill', \
      grTitle: Group {\
        spacing: 6, \
        foldIcon: Custom { preferredSize: [8, 8] }, \
        txt: StaticText {}, \
      }, \
    }",
    );

    this.element.grTitle.txt.text = title;

    var foldIcon = this.element.grTitle.foldIcon;

    this.element.grTitle.addEventListener(
      "click",
      bind(function (event) {
        if (event.eventPhase === "target") {
          this.toggleInfo();
          foldIcon.notify("onDraw");
        }
      }, this),
    );

    foldIcon.onDraw = bind(function () {
      var g = this.element.grTitle.foldIcon.graphics;
      var c = this.element.isMouseOver
        ? [0.75, 0.75, 0.75, 1]
        : [0.55, 0.55, 0.55, 1];
      var b = g.newPen(g.PenType.SOLID_COLOR, c, 2);

      if (this.isUnfoldInfo) {
        g.moveTo(0, 2);
        g.lineTo(4, 6);
        g.lineTo(8, 2);
      } else {
        g.moveTo(0, 0);
        g.lineTo(4, 4);
        g.lineTo(0, 8);
      }

      g.strokePath(b);
    }, this);

    this.element.grTitle.addEventListener(
      "mouseover",
      bind(function (event) {
        if (event.eventPhase === "target") {
          this.element.isMouseOver = true;
          foldIcon.notify("onDraw");
        }
      }, this),
    );

    this.element.grTitle.addEventListener(
      "mouseout",
      bind(function (event) {
        if (event.eventPhase === "target") {
          this.element.isMouseOver = false;
          foldIcon.notify("onDraw");
        }
      }, this),
    );
  }

  FoldingInfo.prototype.toggleInfo = function () {
    if (this.isUnfoldInfo) {
      this.foldInfo();
    } else {
      this.unfoldInfo();
    }

    this.element.parent.layout.layout(true);
    this.element.parent.layout.resize();
  };

  FoldingInfo.prototype.unfoldInfo = function () {
    if (this.isUnfoldInfo) {
      this.foldInfo();
    }

    var grInfo = this.element.add(
      "Group { \
        orientation: 'column', \
        alignChildren: ['fill', 'fill'], \
        grLine: Group { alignment: 'fill', orientation: 'column' }, \
    }",
    );

    Line(grInfo.grLine);

    if (typeof this.unfoldEl === "string") {
      grInfo.add(this.unfoldEl);
    } else if (typeof this.unfoldEl === "function") {
      this.unfoldEl(grInfo);
    }

    this.element.grInfo = grInfo;
    this.isUnfoldInfo = true;
  };

  FoldingInfo.prototype.foldInfo = function () {
    if (!this.isUnfoldInfo) {
      return;
    }

    var grInfo = this.element.grInfo;

    if (grInfo && isValid(grInfo)) {
      grInfo.parent.remove(grInfo);
    }

    this.isUnfoldInfo = false;
  };

  function PluginSettings(parentEl) {
    zoomPlugin.resetStatus();
    this.tabs = parentEl;

    this.element = parentEl.add(
      "tab { \
      text: 'Plug-in', \
      alignChildren: ['fill', 'top'], \
      margins: [12, 10, 0, 10], \
      spacing: 10, \
      grTxt: Group { \
        orientation: 'column', \
        alignChildren: 'left', \
        spacing: 4, \
        txt0: StaticText { \
          text: 'Zoom plug-in provides additional features to the script.', \
        }, \
        txt0: StaticText { \
          text: 'It is necessary to have the plug-in installed to use Key Bindings and Experimental settings.', \
        }, \
      }, \
    }",
    );

    this.element.pluginStatusPanel = new PluginStatus(this.element);

    if (
      zoomPlugin.status() !== ZOOM_PLUGIN_STATUS.NOT_FOUND &&
      zoomPlugin.status() !== ZOOM_PLUGIN_STATUS.INITIALIZED_NOT_FOUND
    ) {
      this.element.grMisc = this.element.add(
        "Panel { \
        alignChildren: ['left', 'top'], \
        text: 'Plug-in', \
        txtVersion: StaticText {}, \
        txtLocation: StaticText {}, \
        grReload: Group { \
          txt: StaticText { text: 'Reload Plug-in: ' }, \
          btnReload: IconButton { \
            title: 'Reload', \
            preferredSize: [100, 22], \
          }, \
        }, \
      }",
      );

      this.element.grMisc.txtVersion.text =
        "Version: " + (zoomPlugin.getVersion() || "unknown");
      this.element.grMisc.txtLocation.text =
        "Location: " + (zoomPlugin.path || "unknown");
      this.element.grMisc.grReload.btnReload.onClick = bind(function () {
        if (zoomPlugin.foundEO) {
          zoomPlugin.reload();

          this.element.pluginStatusPanel.setPluginStatus();
          this.tabs.keyBindings.reloadStatus();
          this.tabs.experimentalSettings.reloadStatus();

          this.element.layout.layout(true);
          this.element.layout.resize();
        }
      }, this);
    }

    /** Fill plug-in install info */
    this.element.pnlInstallPlugin = new FoldingInfo(
      this.element,
      this.fillInstallInfo,
      "How to install the plug-in",
    );

    if (
      this.element.pluginStatusPanel.pluginStatus !==
      ZOOM_PLUGIN_STATUS.INITIALIZED
    ) {
      this.element.pnlInstallPlugin.unfoldInfo();
    }
  }

  PluginSettings.prototype.fillInstallInfo = function (parentGr) {
    var grInstallInfo = parentGr.add(
      "Group { \
      orientation: 'column', \
      alignChildren: ['left', 'center'], \
      txt1: StaticText { \
        characters: 50, \
        properties: { multiline: true } \
      }, \
      txt2: StaticText {}, \
      grPath: Group { \
        alignment: 'fill', \
        orientation: 'column', \
      }, \
      txt3: StaticText { text: '3. Restart After Effects.' }, \
    }",
    );

    grInstallInfo.txt1.text =
      "1. Find the plug-in file in the same archive that contains this script. The plug-in can be found at '" +
      (AE_OS == OS.WIN ? "Plug-in/Windows/" : "Plug-in/macOS/") +
      PLUGIN_FILE_NAME +
      "' inside the archive.";

    grInstallInfo.txt2.text =
      "2. Copy the plug-in file (" +
      PLUGIN_FILE_NAME +
      ") in one of the following directories:";

    parentGr.grInstallInfo = grInstallInfo;

    function addPathElement(parentEl, path, title) {
      var grPath = parentEl.add(
        "Group { \
        alignment: 'fill', \
        alignChildren: 'fill', \
        orientation: 'column', \
        spacing: 3, \
        txtTitle: StaticText {}, \
        grTextPath: Group { \
          margins: [12, 0, 0, 0], \
          txtPath: EditText { \
            alignment: ['fill', 'center' ], \
            properties: { readonly: true }, \
            text: 'After Effects Plug-ins folder', \
          }, \
          btnOpen: IconButton { \
            alignment: ['right', 'center' ], \
            title: 'Open', \
            preferredSize: [60, 22], \
          }, \
        }, \
      }",
      );

      grPath.txtTitle.text = title;
      grPath.grTextPath.txtPath.text = path;
      grPath.grTextPath.btnOpen.onClick = function () {
        var folder = new Folder(path);
        if (folder.exists) {
          openURL(path);
        } else {
          alert("Folder does not exist.");
        }
      };
    }

    var pluginsFoldersPaths = getPluginsFoldersPaths();

    addPathElement(
      grInstallInfo.grPath,
      pluginsFoldersPaths.common,
      "(Recommended) For all versions of After Effects:",
    );
    addPathElement(
      grInstallInfo.grPath,
      pluginsFoldersPaths.individual,
      "Only for this version of After Effects:",
    );
  };

  function SettingsWindow(zoom) {
    this.saveOnClose = false;

    this.element = new Window(
      "palette { \
      margins: 0, \
      spacing: 0, \
    }",
      "Zoom Settings",
      undefined,
    );

    var tabs = this.element.add(
      "tabbedpanel { \
      properties: { name: 'tabs' }, \
      alignment: ['fill', 'fill'], \
      minimumSize: [560, 350], \
    }",
    );

    tabs.general = new GeneralSettings(tabs, zoom);
    tabs.plugin = new PluginSettings(tabs);
    tabs.keyBindings = new KeyBindingsSettings(tabs);
    tabs.experimentalSettings = new ExperimentalSettings(tabs);

    this.tabsArr = [
      tabs.general,
      tabs.plugin,
      tabs.keyBindings,
      tabs.experimentalSettings,
    ];

    /** Draw Key Bindings tab only when it's selected because it takes too long to draw */
    tabs.onChange = function () {
      if (this.selection === tabs.keyBindings.element) {
        this.keyBindings.draw();
      }
    };

    this.element.grButtons = this.element.add(
      "Group { \
      alignment: ['fill', 'bottom'], \
      margins: 10, \
      alignChildren: ['right', 'center'], \
      btnSave: IconButton { title: 'OK', preferredSize: [100, 22] }, \
      btnCancel: IconButton { title: 'Cancel', preferredSize: [100, 22] }, \
    }",
    );

    this.element.grButtons.btnSave.onClick = bind(function () {
      this.saveOnClose = true;

      /** Close the window */
      this.element.close();
    }, this);

    this.element.grButtons.btnCancel.onClick = bind(function () {
      /** Close the window */
      this.element.close();
    }, this);

    this.element.onClose = bind(function () {
      if (this.saveOnClose) {
        this.saveChanges();
      } else {
        this.cancelChanges();
      }
    }, this);

    // this.element.layout.layout(true);
    this.element.show();
  }

  SettingsWindow.prototype.saveChanges = function () {
    for (var i = 0; i < this.tabsArr.length; i++) {
      if (typeof this.tabsArr[i].save === "function") {
        this.tabsArr[i].save();
      }
    }
  };

  SettingsWindow.prototype.cancelChanges = function () {
    for (var i = 0; i < this.tabsArr.length; i++) {
      if (typeof this.tabsArr[i].cancel === "function") {
        this.tabsArr[i].cancel();
      }
    }
  };

  function Settings(zoom, parentEl) {
    this.element = parentEl.add(
      "Group { \
      alignChildren: ['center', 'center'], \
      margins: [5, 0, 5, 0], \
      grDots: Custom { preferredSize: [4, 20] }, \
    }",
    );

    this.element.grDots.addEventListener("mouseover", function () {
      this.notify("onDraw");
    });

    this.element.grDots.addEventListener("mouseout", function () {
      this.notify("onDraw");
    });

    this.element.grDots.onDraw = function (drawState) {
      var g = this.graphics;
      var c = drawState.mouseOver ? [0.75, 0.75, 0.75, 1] : [0.55, 0.55, 0.55, 1];
      var b = g.newBrush(g.BrushType.SOLID_COLOR, c);

      g.ellipsePath(0, 4, 2, 2);
      g.fillPath(b);

      g.ellipsePath(0, 9, 2, 2);
      g.fillPath(b);

      g.ellipsePath(0, 14, 2, 2);
      g.fillPath(b);
    };

    this.element.addEventListener(
      "click",
      bind(function (event) {
        if (event.eventPhase === "target") {
          this.menuWindow = new MenuWindow();
          var menuWindow = this.menuWindow;

          this.settingsItem = menuWindow.addMenuItem("Settings", function () {
            windows.new(new SettingsWindow(zoom));
          });

          menuWindow.addDivider();
          menuWindow.addMenuItem("About", function () {
            windows.new(new AboutWindow());
          });
          menuWindow.addMenuItem("Github", function () {
            openURL("https://github.com/QuisPic/ae-zoom");
          });

          menuWindow.element.opacity = 0;
          menuWindow.element.show();
          menuWindow.stickTo(
            this.element,
            STICK_TO.RIGHT,
            event,
            this.element.grDots,
          );
          menuWindow.element.opacity = 1;
        }
      }, this),
    );
  }

  function Slider(
    zoom,
    parentEl,
    onChangeFn,
    onScrubStartFn,
    onScrubEndFn,
    initVal,
    min,
    max,
  ) {
    this.parentEl = parentEl;

    this.element = parentEl.add(
      "Group { \
      spacing: 1, \
      alignment: ['fill', 'center'], \
      grDecrement: Group { \
        orientation: 'stack', \
        alignment: ['left', 'center'], \
        alignChildren: ['fill', 'fill'], \
      }, \
      slider: Slider { \
        preferredSize: [150, -1], \
        alignment: ['fill', 'center'], \
      }, \
      grIncrement: Group { \
        orientation: 'stack', \
        alignment: ['right', 'center'], \
        alignChildren: ['fill', 'fill'], \
      }, \
    }",
    );

    this.setMin(min);
    this.setMax(max);
    this.setValue(initVal);
    this.lastValue = initVal;

    var slider = this.element.slider;

    slider.onChange = function () {
      if (typeof onScrubEndFn === "function") {
        onScrubEndFn();
      }

      this.scrubbing = false;
    };

    slider.onChanging = function () {
      if (!this.scrubbing) {
        if (typeof onScrubStartFn === "function") {
          onScrubStartFn();
        }

        this.scrubbing = true;
      }

      if (typeof onChangeFn === "function" && this.scrubbing) {
        onChangeFn(Math.round(this.value));
      }
    };
  }

  Slider.prototype.addIncrementBtns = function (zoom, onIncrementFn) {
    var grIncrement = this.element.grIncrement;
    var grDecrement = this.element.grDecrement;

    grDecrement.zoomIcon = grDecrement.add("Group { preferredSize: [25, 16] }");
    grDecrement.grLight = grDecrement.add("Group { visible: false }");

    grIncrement.zoomIcon = grIncrement.add("Group { preferredSize: [25, 16] }");
    grIncrement.grLight = grIncrement.add("Group { visible: false }");

    var g = grDecrement.grLight.graphics;
    var lightBrush = g.newBrush(g.BrushType.SOLID_COLOR, [1, 1, 1, 0.06]);

    function increment(zoomStep, mouseEvent) {
      if (checkOs() === OS.WIN ? mouseEvent.ctrlKey : mouseEvent.metaKey) {
        zoomStep /= 10;
      } else if (mouseEvent.shiftKey) {
        zoomStep *= 10;
      }

      var newValue = makeDivisibleBy(
        zoom.zoomNumberValue.getValue() + zoomStep,
        zoomStep,
        zoomStep < 0,
      );

      // this.element.slider.value = newValue;
      zoom.zoomSlider.setValue(newValue);

      if (typeof onIncrementFn === "function") {
        onIncrementFn(newValue);
      }
    }

    function showLight(event) {
      if (event.eventPhase === "target") {
        this.zoomIcon.light = true;
        this.grLight.show();
      }
    }

    function hideLight(event) {
      if (event.eventPhase === "target") {
        this.zoomIcon.light = false;
        this.grLight.hide();
      }
    }

    grDecrement.grLight.graphics.backgroundColor = lightBrush;
    grIncrement.grLight.graphics.backgroundColor = lightBrush;

    grIncrement.zoomIcon.onDraw = function () {
      var g = this.graphics;
      var c = this.light ? [0.9, 0.9, 0.9, 1] : [0.65, 0.65, 0.65, 1];
      var b = g.newBrush(g.BrushType.SOLID_COLOR, c);

      g.moveTo(3, this.size[1] - 4);
      g.lineTo(g.currentPoint[0] + 6, g.currentPoint[1] - 6);
      g.lineTo(g.currentPoint[0] + 2, g.currentPoint[1] + 2);
      g.lineTo(g.currentPoint[0] - 4, g.currentPoint[1] + 4);
      g.fillPath(b);

      var lastPoint = g.currentPoint;
      g.currentPath = g.newPath();
      g.moveTo(lastPoint[0] + 1, lastPoint[1]);
      g.lineTo(g.currentPoint[0] + 7, g.currentPoint[1] - 8);
      g.lineTo(g.currentPoint[0] + 7, g.currentPoint[1] + 8);
      g.fillPath(b);
    };

    grDecrement.zoomIcon.onDraw = function () {
      var g = this.graphics;
      var c = this.light ? [0.9, 0.9, 0.9, 1] : [0.65, 0.65, 0.65, 1];
      var b = g.newBrush(g.BrushType.SOLID_COLOR, c);

      g.moveTo(8, this.size[1] - 5);
      g.lineTo(g.currentPoint[0] + 3, g.currentPoint[1] - 3);
      g.lineTo(g.currentPoint[0] + 1, g.currentPoint[1] + 1);
      g.lineTo(g.currentPoint[0] - 2, g.currentPoint[1] + 2);
      g.fillPath(b);

      var lastPoint = g.currentPoint;
      g.currentPath = g.newPath();
      g.moveTo(lastPoint[0], lastPoint[1]);
      g.lineTo(g.currentPoint[0] + 4, g.currentPoint[1] - 4);
      g.lineTo(g.currentPoint[0] + 4, g.currentPoint[1] + 4);
      g.fillPath(b);
    };

    grIncrement.addEventListener("click", function (event) {
      if (event.eventPhase === "target") {
        increment(ZOOM_STEP_ON_BTN_CLICK, event);
      }
    });

    grDecrement.addEventListener("click", function (event) {
      if (event.eventPhase === "target") {
        increment(-ZOOM_STEP_ON_BTN_CLICK, event);
      }
    });

    grDecrement.addEventListener("mouseover", showLight);
    grIncrement.addEventListener("mouseover", showLight);
    grDecrement.addEventListener("mouseout", hideLight);
    grIncrement.addEventListener("mouseout", hideLight);
  };

  Slider.prototype.getValue = function () {
    return Math.round(this.element.slider.value);
  };

  Slider.prototype.setValue = function (val) {
    this.element.slider.value = val;
    this.lastValue = this.element.slider.value;
  };

  Slider.prototype.getMin = function () {
    return this.element.slider.minvalue;
  };

  Slider.prototype.getMax = function () {
    return this.element.slider.maxvalue;
  };

  Slider.prototype.setMin = function (min) {
    this.element.slider.minvalue = min;
  };

  Slider.prototype.setMax = function (max) {
    this.element.slider.maxvalue = max;
  };

  function ValueList(parentEl, onChangeFn, targetEl, stickTo) {
    var thisValueList = this;
    this.targetEl = targetEl;
    stickTo = stickTo || STICK_TO.LEFT;

    this.element = parentEl.add(
      "Group { \
      alignment: ['left', 'center'], \
      icon: Custom { \
        preferredSize: [20, 20], \
      }, \
    }",
    );

    function handleIconMouseOver(event) {
      if (event.eventPhase === "target") {
        this.notify("onDraw");
      }
    }

    this.element.icon.addEventListener("mouseover", handleIconMouseOver);
    this.element.icon.addEventListener("mouseout", handleIconMouseOver);

    this.element.icon.onDraw = function (drawState) {
      var g = this.graphics;
      var c = drawState.mouseOver ? [0.75, 0.75, 0.75, 1] : [0.55, 0.55, 0.55, 1];

      g.moveTo(7, 7);
      g.lineTo(10, 13);
      g.lineTo(13, 7);
      g.closePath();
      g.fillPath(g.newBrush(g.BrushType.SOLID_COLOR, c));
    };

    this.element.addEventListener("click", function (event) {
      function createOnClickFn(val) {
        if (typeof onChangeFn === "function") {
          return function () {
            onChangeFn(val);
          };
        }
      }

      if (event.eventPhase === "target") {
        var listWindow = new MenuWindow();

        var valuesArr =
          typeof preferences.presetValues === "string"
            ? JSON.parse(preferences.presetValues)
            : preferences.presetValues;

        for (var i = 0; i < valuesArr.length; i++) {
          listWindow.addMenuItem(
            valuesArr[i] + "%",
            createOnClickFn(valuesArr[i]),
          );
        }

        listWindow.element.opacity = 0;
        listWindow.element.show();
        listWindow.stickTo(this, stickTo, event, thisValueList.targetEl);
        listWindow.element.opacity = 1;
      }
    });
  }

  function Zoom(thisObj) {
    var currentZoom = Zoom.getViewZoom();

    this.w =
      thisObj instanceof Panel
        ? thisObj
        : new Window("palette", "Zoom", undefined, { resizeable: true });

    this.w.orientation = "row";
    this.w.alignChildren = ["left", "center"];
    this.w.spacing = 2;
    this.w.margins = this.w instanceof Panel ? [2, 0, 2, 0] : [5, 5, 8, 5];

    this.w.onResize = function () {
      this.layout.resize();
    };

    this.w.onResizing = this.w.onResize;

    this.zoomNumberValue = new NumberValue(
      this.w,
      "%",
      currentZoom,
      1,
      undefined,
      this.produceSetTo(),
    );

    this.zoomNumberValue.element.addEventListener(
      "mouseover",
      this.produceSyncOnMouseOver(),
    );

    this.zoomValueList = new ValueList(
      this.w,
      bind(function (val) {
        this.setTo(val);
        this.setUiTo(val);
      }, this),
      this.zoomNumberValue.element,
      STICK_TO.LEFT,
    );
    this.w.grSlider = this.w.add("group");
    this.settings = new Settings(this, this.w);

    if (preferences.showSlider) {
      this.addSlider();
    }
  }

  Zoom.prototype.addSlider = function () {
    this.zoomSlider = new Slider(
      this,
      this.w.grSlider,
      this.produceSliderOnChange(),
      this.produceSliderOnScrubStart(),
      this.produceSliderOnScrubEnd(),
      this.zoomNumberValue.getValue(),
      preferences.sliderMin || 1,
      preferences.sliderMax,
    );

    this.zoomSlider.element.addEventListener(
      "mouseover",
      this.produceSyncOnMouseOver(),
    );

    this.zoomSlider.addIncrementBtns(this, this.produceOnIncrement());

    this.w.grSlider.alignment = ["fill", "center"];
    this.settings.element.alignment = ["right", "center"];
  };

  Zoom.getViewZoom = function () {
    var zoomValue = app.activeViewer.views[0].options.zoom;
    zoomValue *= preferences.highDPI.enabled
      ? 100 * preferences.highDPI.scale
      : 100;

    return parseFloat(zoomValue.toFixed(2));
  };

  Zoom.prototype.setUiTo = function (zoomValue) {
    this.zoomNumberValue.setValue(zoomValue);

    if (this.zoomSlider && isValid(this.zoomSlider.element)) {
      this.zoomSlider.setValue(zoomValue);
    }
  };

  Zoom.prototype.setTo = function (zoomValue) {
    zoomValue = zoomValue < 0.8 ? 0.8 : zoomValue;
    var isActionPosted = false;

    if (
      preferences.experimental.fixViewportPosition.enabled &&
      zoomPlugin.isAvailable()
    ) {
      isActionPosted = zoomPlugin.postZoomAction(KB_ACTION.SET_TO, zoomValue);
    }

    if (!isActionPosted) {
      zoomValue /= preferences.highDPI.enabled
        ? 100 * preferences.highDPI.scale
        : 100;
      app.activeViewer.views[0].options.zoom = zoomValue;
    }
  };

  Zoom.prototype.syncWithView = function () {
    var viewZoomValue = Zoom.getViewZoom();

    if (viewZoomValue !== this.zoomNumberValue.getValue()) {
      this.setUiTo(viewZoomValue);
    }
  };

  // function factory for passing the func to other functions
  Zoom.prototype.produceSetTo = function () {
    var thisZoom = this;

    return function (zoomValue) {
      thisZoom.setTo(zoomValue);
    };
  };

  Zoom.prototype.produceSyncOnMouseOver = function () {
    var thisZoom = this;

    return function (event) {
      if (event.eventPhase === "target" && preferences.syncWithView) {
        thisZoom.syncWithView();
      }
    };
  };

  Zoom.prototype.produceSliderOnScrubStart = function () {
    var thisZoom = this;

    return function () {
      var viewer = app.activeViewer.views[0];

      thisZoom.origExposure = viewer.options.exposure;
    };
  };

  Zoom.prototype.produceSliderOnChange = function () {
    var thisZoom = this;

    return function (zoomValue) {
      var viewer = app.activeViewer.views[0];

      thisZoom.setTo(zoomValue);
      thisZoom.setUiTo(zoomValue);

      // this exposure trick makes AE refresh the view panel everytime we move the slider
      if (thisZoom.origExposure !== undefined) {
        viewer.options.exposure =
          viewer.options.exposure === thisZoom.origExposure
            ? thisZoom.origExposure + 0.01
            : thisZoom.origExposure;
      }
    };
  };

  Zoom.prototype.produceSliderOnScrubEnd = function () {
    var thisZoom = this;

    return function () {
      var viewer = app.activeViewer.views[0];

      if (thisZoom.origExposure !== undefined) {
        viewer.options.exposure = thisZoom.origExposure;
        thisZoom.origExposure = undefined;
      }
    };
  };

  Zoom.prototype.produceOnIncrement = function () {
    var thisZoom = this;

    return function (zoomValue) {
      var currValue = thisZoom.zoomNumberValue.getValue();
      var viewValue = Zoom.getViewZoom();

      if (preferences.syncWithView && currValue !== viewValue) {
        zoomValue = viewValue + (zoomValue - currValue);
      }

      thisZoom.setTo(zoomValue);
      thisZoom.setUiTo(zoomValue);
    };
  };

  Zoom.prototype.showHideSlider = function (val) {
    val = val === undefined ? !preferences.showSlider : val;
    var hasSlider = this.zoomSlider && isValid(this.zoomSlider.element);

    if (val && !hasSlider) {
      this.addSlider();
    } else if (!val && hasSlider) {
      this.zoomSlider.parentEl.remove(this.zoomSlider.element);
      this.zoomSlider.parentEl.preferredSize = [0, 0];

      this.w.grSlider.alignment = ["left", "center"];
      this.settings.element.alignment = ["left", "center"];
    }

    preferences.save("showSlider", val);

    this.w.layout.layout(true);
    this.w.layout.resize();
  };

  var zoom = new Zoom(__zoomThisObj);

  if (zoom.w instanceof Panel) {
    zoom.w.layout.layout(true);
    zoom.w.layout.resize();
  } else {
    zoom.w.show();
  }

})();
